<#
.SYNOPSIS
    Funciones comunes utilizadas por todos los módulos del M365 Health Check.
.DESCRIPTION
    Logging, creación de estructura de carpetas por ejecución, exportación de
    resultados (CSV/JSON) y validaciones básicas de conexión a Microsoft Graph.
    Este archivo se "dot-source" desde el orquestador y desde cada módulo.
#>

# ------------------------------------------------------------------
# Logging
# ------------------------------------------------------------------
function Write-Log {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)] [string]$Message,
        [ValidateSet('INFO','WARN','ERROR','OK')] [string]$Level = 'INFO',
        [Parameter(Mandatory)] [string]$LogFile
    )

    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "[{0}] [{1,-5}] {2}" -f $timestamp, $Level, $Message

    switch ($Level) {
        'ERROR' { Write-Host $line -ForegroundColor Red }
        'WARN'  { Write-Host $line -ForegroundColor Yellow }
        'OK'    { Write-Host $line -ForegroundColor Green }
        default { Write-Host $line }
    }

    try {
        Add-Content -Path $LogFile -Value $line -Encoding UTF8
    }
    catch {
        Write-Host "No se pudo escribir en el log '$LogFile': $($_.Exception.Message)" -ForegroundColor Red
    }
}

# ------------------------------------------------------------------
# Estructura de carpetas (sección 6 del documento, una carpeta por ejecución
# como se describe en la sección 11: C:\M365-HealthCheck\2026-09-21\...)
# ------------------------------------------------------------------
function Initialize-HealthCheckFolders {
    [CmdletBinding()]
    param(
        [string]$BasePath = 'C:\M365-HealthCheck',
        [string]$RunId = (Get-Date -Format 'yyyy-MM-dd_HHmmss')
    )

    $runPath = Join-Path $BasePath $RunId

    $subfolders = @(
        '00-Execution',
        '01-Exchange',
        '02-EntraID-Graph',
        '03-Security',
        '04-Compliance',
        '05-Licensing',
        '06-Applications',
        '07-DNS',
        '08-Report'
    )

    if (-not (Test-Path $runPath)) {
        New-Item -Path $runPath -ItemType Directory -Force | Out-Null
    }

    $paths = @{ Root = $runPath }

    foreach ($folder in $subfolders) {
        $full = Join-Path $runPath $folder
        New-Item -Path $full -ItemType Directory -Force | Out-Null
        # Clave sin guiones ni números para acceso cómodo, p.ej. $Paths.EntraIDGraph
        $key = ($folder -replace '^\d+-', '') -replace '-', ''
        $paths[$key] = $full
    }

    return $paths
}

# ------------------------------------------------------------------
# Exportación de resultados: siempre CSV, y opcionalmente JSON
# ------------------------------------------------------------------
function Export-ModuleResult {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)] $Data,
        [Parameter(Mandatory)] [string]$FolderPath,
        [Parameter(Mandatory)] [string]$FileName,
        [switch]$AlsoJson
    )

    if ($null -eq $Data) { return }

    if (-not (Test-Path $FolderPath)) {
        New-Item -Path $FolderPath -ItemType Directory -Force | Out-Null
    }

    $csvPath = Join-Path $FolderPath "$FileName.csv"
    $Data | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8

    if ($AlsoJson) {
        $jsonPath = Join-Path $FolderPath "$FileName.json"
        $Data | ConvertTo-Json -Depth 6 | Out-File -FilePath $jsonPath -Encoding UTF8
    }

    return $csvPath
}

# ------------------------------------------------------------------
# Validación de conexión a Microsoft Graph
# ------------------------------------------------------------------
function Test-GraphConnection {
    [CmdletBinding()]
    param([string]$LogFile)

    try {
        $context = Get-MgContext
        if ($null -eq $context) {
            if ($LogFile) { Write-Log -Message 'No hay una sesión activa de Microsoft Graph (Get-MgContext devolvió $null).' -Level 'ERROR' -LogFile $LogFile }
            return $false
        }
        return $true
    }
    catch {
        if ($LogFile) { Write-Log -Message "Error al validar la conexión a Graph: $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile }
        return $false
    }
}

# ------------------------------------------------------------------
# Envoltura estándar para ejecutar cada módulo con manejo de errores
# consistente (para que si un módulo falla, no se detenga todo el Health Check)
# ------------------------------------------------------------------
function Invoke-HealthCheckModule {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)] [string]$Name,
        [Parameter(Mandatory)] [scriptblock]$ScriptBlock,
        [Parameter(Mandatory)] [string]$LogFile
    )

    Write-Log -Message "==== Iniciando módulo: $Name ====" -Level 'INFO' -LogFile $LogFile
    $sw = [System.Diagnostics.Stopwatch]::StartNew()

    try {
        & $ScriptBlock
        $sw.Stop()
        Write-Log -Message "Módulo '$Name' finalizado correctamente en $($sw.Elapsed.ToString('mm\:ss'))." -Level 'OK' -LogFile $LogFile
        return [pscustomobject]@{ Module = $Name; Status = 'OK'; DurationSec = [math]::Round($sw.Elapsed.TotalSeconds,1); Error = $null }
    }
    catch {
        $sw.Stop()
        Write-Log -Message "Módulo '$Name' falló: $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile
        return [pscustomobject]@{ Module = $Name; Status = 'ERROR'; DurationSec = [math]::Round($sw.Elapsed.TotalSeconds,1); Error = $_.Exception.Message }
    }
}

# Nota: este archivo se usa con dot-sourcing ( . .\Common-Functions.ps1 ),
# no como módulo .psm1, por lo que no se usa Export-ModuleMember.
