<#
.SYNOPSIS
    Módulo 06 - Licenciamiento (Microsoft Graph).
.DESCRIPTION
    Recolecta SKUs suscritos (consumo total/disponible) y el detalle de
    licencias asignadas por usuario.
#>

function Invoke-LicenciamientoModule {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)] [hashtable]$Paths,
        [Parameter(Mandatory)] [string]$LogFile
    )

    $folder = $Paths.Licensing

    # --- SKUs suscritos -----------------------------------------------
    $skus = @()
    try {
        Write-Log -Message 'Consultando SKUs suscritos (Get-MgSubscribedSku)...' -Level 'INFO' -LogFile $LogFile
        $skus = Get-MgSubscribedSku -All -ErrorAction Stop
        $skus | Select-Object SkuPartNumber, SkuId,
            @{N='Enabled';E={$_.PrepaidUnits.Enabled}},
            @{N='Consumed';E={$_.ConsumedUnits}},
            @{N='Available';E={$_.PrepaidUnits.Enabled - $_.ConsumedUnits}} |
            Export-ModuleResult -FolderPath $folder -FileName 'SubscribedSkus' -AlsoJson
        Write-Log -Message "SKUs encontrados: $($skus.Count)" -Level 'OK' -LogFile $LogFile
    }
    catch { Write-Log -Message "Error obteniendo SKUs: $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile }

    # --- Mapa SkuId -> Nombre legible para el detalle por usuario -----------
    $skuMap = @{}
    foreach ($s in $skus) { $skuMap[$s.SkuId.ToString()] = $s.SkuPartNumber }

    # --- Licencias por usuario -----------------------------------------------
    try {
        Write-Log -Message 'Consultando licencias asignadas por usuario...' -Level 'INFO' -LogFile $LogFile
        $users = Get-MgUser -All -Property Id, DisplayName, UserPrincipalName, AccountEnabled, AssignedLicenses -ErrorAction Stop

        $licenseDetail = foreach ($u in $users) {
            if ($u.AssignedLicenses.Count -eq 0) {
                [pscustomobject]@{
                    DisplayName       = $u.DisplayName
                    UserPrincipalName = $u.UserPrincipalName
                    AccountEnabled    = $u.AccountEnabled
                    License           = '(sin licencia)'
                }
            }
            else {
                foreach ($lic in $u.AssignedLicenses) {
                    $skuName = $skuMap[$lic.SkuId.ToString()]
                    if (-not $skuName) { $skuName = $lic.SkuId }
                    [pscustomobject]@{
                        DisplayName       = $u.DisplayName
                        UserPrincipalName = $u.UserPrincipalName
                        AccountEnabled    = $u.AccountEnabled
                        License           = $skuName
                    }
                }
            }
        }

        $licenseDetail | Export-ModuleResult -FolderPath $folder -FileName 'UserLicenseDetail'

        $unlicensed = ($licenseDetail | Where-Object { $_.License -eq '(sin licencia)' }).Count
        Write-Log -Message "Usuarios evaluados: $($users.Count). Sin licencia: $unlicensed" -Level 'OK' -LogFile $LogFile
    }
    catch { Write-Log -Message "Error obteniendo licencias por usuario: $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile }

    return $true
}
