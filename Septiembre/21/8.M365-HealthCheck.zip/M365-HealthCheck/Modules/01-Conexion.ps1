<#
.SYNOPSIS
    Módulo 01 - Conexión.
.DESCRIPTION
    Corresponde a las secciones 1-4 y 10 del documento:
      - Valida PowerShell 7
      - Valida que el módulo Microsoft.Graph esté instalado
      - Conecta a Microsoft Graph con los scopes indicados
      - Valida el contexto (Get-MgContext) y hace una consulta de prueba
    Si este módulo falla, el resto del Health Check no se ejecuta,
    porque todos los demás módulos dependen de la sesión de Graph.
#>

function Invoke-ConexionModule {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)] [string[]]$Scopes,
        [Parameter(Mandatory)] [hashtable]$Paths,
        [Parameter(Mandatory)] [string]$LogFile
    )

    # --- Paso 1: Validar PowerShell 7 -------------------------------------
    Write-Log -Message "Versión de PowerShell detectada: $($PSVersionTable.PSVersion) ($($PSVersionTable.PSEdition))" -Level 'INFO' -LogFile $LogFile
    if ($PSVersionTable.PSVersion.Major -lt 7) {
        Write-Log -Message 'Se recomienda PowerShell 7 para este proyecto. Continuando de todos modos, pero si algo falla, ejecuta este script desde PowerShell 7.' -Level 'WARN' -LogFile $LogFile
    }

    # --- Paso 2: Validar módulo Microsoft.Graph ---------------------------
    $graphModule = Get-Module -ListAvailable -Name Microsoft.Graph | Sort-Object Version -Descending | Select-Object -First 1
    if (-not $graphModule) {
        throw "El módulo Microsoft.Graph no está instalado. Instálalo con: Install-Module Microsoft.Graph -Scope CurrentUser"
    }
    Write-Log -Message "Microsoft.Graph versión $($graphModule.Version) encontrado." -Level 'OK' -LogFile $LogFile

    Import-Module Microsoft.Graph.Authentication -ErrorAction Stop
    Import-Module Microsoft.Graph.Users -ErrorAction Stop

    # --- Paso 3: Conectar a Microsoft Graph -------------------------------
    $existingContext = Get-MgContext
    $needsConnect = $true

    if ($existingContext) {
        $missingScopes = $Scopes | Where-Object { $_ -notin $existingContext.Scopes }
        if (-not $missingScopes) {
            Write-Log -Message "Ya existe una sesión de Graph activa como '$($existingContext.Account)' con los scopes requeridos." -Level 'OK' -LogFile $LogFile
            $needsConnect = $false
        }
        else {
            Write-Log -Message "Sesión existente no tiene todos los scopes requeridos ($($missingScopes -join ', ')). Reconectando." -Level 'WARN' -LogFile $LogFile
        }
    }

    if ($needsConnect) {
        Write-Log -Message "Conectando a Microsoft Graph con scopes: $($Scopes -join ', ')" -Level 'INFO' -LogFile $LogFile
        Write-Log -Message 'Se abrirá una ventana de autenticación. Usa la cuenta administrativa del Health Check.' -Level 'INFO' -LogFile $LogFile
        Connect-MgGraph -Scopes $Scopes -NoWelcome -ErrorAction Stop
    }

    # --- Paso 4: Validar contexto -----------------------------------------
    $context = Get-MgContext
    if (-not $context) {
        throw 'Get-MgContext no devolvió información. La conexión a Microsoft Graph no se estableció correctamente.'
    }

    Write-Log -Message "Conectado como: $($context.Account)" -Level 'OK' -LogFile $LogFile
    Write-Log -Message "TenantId: $($context.TenantId)" -Level 'INFO' -LogFile $LogFile
    Write-Log -Message "AuthType: $($context.AuthType)" -Level 'INFO' -LogFile $LogFile
    Write-Log -Message "Scopes otorgados: $($context.Scopes -join ', ')" -Level 'INFO' -LogFile $LogFile

    $missingScopes = $Scopes | Where-Object { $_ -notin $context.Scopes }
    if ($missingScopes) {
        Write-Log -Message "Los siguientes scopes solicitados NO aparecen en el contexto (puede requerirse admin consent): $($missingScopes -join ', ')" -Level 'WARN' -LogFile $LogFile
    }

    # Guardar el contexto de conexión como evidencia en 00-Execution
    [pscustomobject]@{
        Account   = $context.Account
        TenantId  = $context.TenantId
        AuthType  = $context.AuthType
        AppName   = $context.AppName
        Scopes    = ($context.Scopes -join '; ')
        Timestamp = (Get-Date)
    } | Export-ModuleResult -FolderPath $Paths.Execution -FileName 'Connection-Context'

    # --- Prueba de consulta sencilla (sección 4) --------------------------
    Write-Log -Message 'Ejecutando consulta de prueba: Get-MgUser -Top 10' -Level 'INFO' -LogFile $LogFile
    $testUsers = Get-MgUser -Top 10 -Property DisplayName, UserPrincipalName, AccountEnabled -ErrorAction Stop |
        Select-Object DisplayName, UserPrincipalName, AccountEnabled

    if (-not $testUsers) {
        throw 'La consulta de prueba Get-MgUser -Top 10 no devolvió usuarios. Revisa los permisos antes de continuar.'
    }

    Write-Log -Message "Consulta de prueba exitosa: $($testUsers.Count) usuario(s) devuelto(s). Microsoft Graph está funcionando correctamente." -Level 'OK' -LogFile $LogFile
    $testUsers | Export-ModuleResult -FolderPath $Paths.Execution -FileName 'Connection-TestQuery'

    return $true
}
