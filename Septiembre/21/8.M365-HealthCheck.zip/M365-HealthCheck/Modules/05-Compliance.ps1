<#
.SYNOPSIS
    Módulo 05 - Compliance.
.DESCRIPTION
    Parte con Microsoft Graph (etiquetas de retención/sensibilidad expuestas
    vía Graph). La información más completa de cumplimiento (políticas DLP,
    retención, eDiscovery) vive en el Security & Compliance Center y requiere
    el módulo ExchangeOnlineManagement + Connect-IPPSSession, NO Microsoft
    Graph. Ese bloque se incluye como opcional y no detiene el Health Check
    si falla o si el módulo no está disponible.
#>

function Invoke-ComplianceModule {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)] [hashtable]$Paths,
        [Parameter(Mandatory)] [string]$LogFile,
        [switch]$SkipIPPS
    )

    $folder = $Paths.Compliance

    # --- Etiquetas de sensibilidad (Microsoft Graph) -----------------------
    try {
        Write-Log -Message 'Consultando etiquetas de sensibilidad (Get-MgInformationProtectionPolicyLabel)...' -Level 'INFO' -LogFile $LogFile
        $labels = Get-MgInformationProtectionPolicyLabel -ErrorAction Stop
        $labels | Select-Object Id, Name, Description, IsActive |
            Export-ModuleResult -FolderPath $folder -FileName 'SensitivityLabels'
        Write-Log -Message "Etiquetas de sensibilidad encontradas: $($labels.Count)" -Level 'OK' -LogFile $LogFile
    }
    catch { Write-Log -Message "Error consultando etiquetas de sensibilidad (requiere InformationProtectionPolicy.Read o licencia adecuada): $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile }

    if ($SkipIPPS) {
        Write-Log -Message 'Se omite el bloque de Security & Compliance Center (SkipIPPS activo).' -Level 'INFO' -LogFile $LogFile
        return $true
    }

    # --- Bloque opcional: Security & Compliance Center (IPPS) ----------------
    $eomModule = Get-Module -ListAvailable -Name ExchangeOnlineManagement | Select-Object -First 1
    if (-not $eomModule) {
        Write-Log -Message 'ExchangeOnlineManagement no está instalado; se omiten políticas de retención/DLP del Compliance Center.' -Level 'WARN' -LogFile $LogFile
        return $true
    }

    try {
        Import-Module ExchangeOnlineManagement -ErrorAction Stop
        Write-Log -Message 'Conectando al Security & Compliance Center (Connect-IPPSSession)...' -Level 'INFO' -LogFile $LogFile
        Connect-IPPSSession -ErrorAction Stop | Out-Null
    }
    catch {
        Write-Log -Message "No se pudo conectar al Compliance Center: $($_.Exception.Message)" -Level 'WARN' -LogFile $LogFile
        return $true
    }

    try {
        Write-Log -Message 'Consultando políticas de retención (Get-RetentionCompliancePolicy)...' -Level 'INFO' -LogFile $LogFile
        $retention = Get-RetentionCompliancePolicy -ErrorAction Stop
        $retention | Select-Object Name, Enabled, Mode, Workload |
            Export-ModuleResult -FolderPath $folder -FileName 'RetentionPolicies'
        Write-Log -Message "Políticas de retención encontradas: $($retention.Count)" -Level 'OK' -LogFile $LogFile
    }
    catch { Write-Log -Message "Error obteniendo políticas de retención: $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile }

    try {
        Write-Log -Message 'Consultando políticas DLP (Get-DlpCompliancePolicy)...' -Level 'INFO' -LogFile $LogFile
        $dlp = Get-DlpCompliancePolicy -ErrorAction Stop
        $dlp | Select-Object Name, Enabled, Mode, Workload |
            Export-ModuleResult -FolderPath $folder -FileName 'DLPPolicies'
        Write-Log -Message "Políticas DLP encontradas: $($dlp.Count)" -Level 'OK' -LogFile $LogFile
    }
    catch { Write-Log -Message "Error obteniendo políticas DLP: $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile }

    try {
        Disconnect-ExchangeOnline -Confirm:$false -ErrorAction SilentlyContinue | Out-Null
    }
    catch { }

    return $true
}
