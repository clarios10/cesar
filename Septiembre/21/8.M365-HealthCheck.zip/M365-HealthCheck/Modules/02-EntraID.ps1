<#
.SYNOPSIS
    Módulo 02 - Entra ID (Microsoft Graph).
.DESCRIPTION
    Recolecta información base del directorio: organización, dominios,
    usuarios, grupos, roles con privilegios y políticas de acceso condicional.
    Cada bloque tiene su propio try/catch: si uno falla, los demás continúan.
#>

function Invoke-EntraIDModule {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)] [hashtable]$Paths,
        [Parameter(Mandatory)] [string]$LogFile
    )

    $folder = $Paths.EntraIDGraph

    # --- Organización -------------------------------------------------
    try {
        Write-Log -Message 'Consultando datos de la organización (Get-MgOrganization)...' -Level 'INFO' -LogFile $LogFile
        $org = Get-MgOrganization -ErrorAction Stop
        $org | Select-Object DisplayName, Id, CountryLetterCode, PreferredLanguage, CreatedDateTime |
            Export-ModuleResult -FolderPath $folder -FileName 'Organization' -AlsoJson
        Write-Log -Message "Organización: $($org.DisplayName)" -Level 'OK' -LogFile $LogFile
    }
    catch { Write-Log -Message "Error obteniendo la organización: $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile }

    # --- Dominios -------------------------------------------------------
    try {
        Write-Log -Message 'Consultando dominios (Get-MgDomain)...' -Level 'INFO' -LogFile $LogFile
        $domains = Get-MgDomain -All -ErrorAction Stop
        $domains | Select-Object Id, IsVerified, IsDefault, IsInitial, AuthenticationType, SupportedServices |
            Export-ModuleResult -FolderPath $folder -FileName 'Domains'
        Write-Log -Message "Dominios encontrados: $($domains.Count)" -Level 'OK' -LogFile $LogFile
    }
    catch { Write-Log -Message "Error obteniendo dominios: $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile }

    # --- Usuarios ---------------------------------------------------------
    try {
        Write-Log -Message 'Consultando usuarios (Get-MgUser -All)...' -Level 'INFO' -LogFile $LogFile
        $props = 'Id,DisplayName,UserPrincipalName,Mail,AccountEnabled,UserType,CreatedDateTime,OnPremisesSyncEnabled,AssignedLicenses'
        $users = Get-MgUser -All -Property $props -ErrorAction Stop
        $users | Select-Object Id, DisplayName, UserPrincipalName, Mail, AccountEnabled, UserType, CreatedDateTime,
            @{N='OnPremisesSync';E={$_.OnPremisesSyncEnabled}},
            @{N='LicenseCount';E={$_.AssignedLicenses.Count}} |
            Export-ModuleResult -FolderPath $folder -FileName 'Users'
        Write-Log -Message "Usuarios encontrados: $($users.Count) (habilitados: $(($users | Where-Object AccountEnabled).Count))" -Level 'OK' -LogFile $LogFile
    }
    catch { Write-Log -Message "Error obteniendo usuarios: $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile }

    # --- Grupos -----------------------------------------------------------
    try {
        Write-Log -Message 'Consultando grupos (Get-MgGroup -All)...' -Level 'INFO' -LogFile $LogFile
        $groups = Get-MgGroup -All -Property Id, DisplayName, Mail, GroupTypes, SecurityEnabled, MailEnabled, CreatedDateTime -ErrorAction Stop
        $groups | Select-Object Id, DisplayName, Mail,
            @{N='IsUnified';E={$_.GroupTypes -contains 'Unified'}},
            SecurityEnabled, MailEnabled, CreatedDateTime |
            Export-ModuleResult -FolderPath $folder -FileName 'Groups'
        Write-Log -Message "Grupos encontrados: $($groups.Count)" -Level 'OK' -LogFile $LogFile
    }
    catch { Write-Log -Message "Error obteniendo grupos: $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile }

    # --- Roles con privilegios y sus miembros ------------------------------
    try {
        Write-Log -Message 'Consultando roles de directorio y sus miembros (Get-MgDirectoryRole)...' -Level 'INFO' -LogFile $LogFile
        $roles = Get-MgDirectoryRole -All -ErrorAction Stop
        $roleMembers = foreach ($role in $roles) {
            $members = Get-MgDirectoryRoleMember -DirectoryRoleId $role.Id -ErrorAction SilentlyContinue
            foreach ($m in $members) {
                [pscustomobject]@{
                    RoleName   = $role.DisplayName
                    RoleId     = $role.Id
                    MemberId   = $m.Id
                    MemberType = $m.AdditionalProperties['@odata.type'] -replace '#microsoft.graph.', ''
                    MemberName = $m.AdditionalProperties['displayName']
                    UPN        = $m.AdditionalProperties['userPrincipalName']
                }
            }
        }
        $roleMembers | Export-ModuleResult -FolderPath $folder -FileName 'PrivilegedRoleMembers'
        Write-Log -Message "Roles evaluados: $($roles.Count). Asignaciones encontradas: $($roleMembers.Count)" -Level 'OK' -LogFile $LogFile
    }
    catch { Write-Log -Message "Error obteniendo roles/miembros: $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile }

    # --- Políticas de acceso condicional ------------------------------------
    try {
        Write-Log -Message 'Consultando políticas de acceso condicional...' -Level 'INFO' -LogFile $LogFile
        $caPolicies = Get-MgIdentityConditionalAccessPolicy -All -ErrorAction Stop
        $caPolicies | Select-Object Id, DisplayName, State, CreatedDateTime, ModifiedDateTime |
            Export-ModuleResult -FolderPath $folder -FileName 'ConditionalAccessPolicies' -AlsoJson
        Write-Log -Message "Políticas de acceso condicional encontradas: $($caPolicies.Count)" -Level 'OK' -LogFile $LogFile
    }
    catch { Write-Log -Message "Error obteniendo políticas de acceso condicional (puede requerir permiso Policy.Read.All): $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile }

    return $true
}
