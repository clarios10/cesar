<#
.SYNOPSIS
    Módulo 04 - Seguridad (Microsoft Graph).
.DESCRIPTION
    Recolecta señales de seguridad: Security Defaults, MFA registration,
    Secure Score y alertas de seguridad recientes.
    Requiere permisos como Policy.Read.All, Reports.Read.All,
    SecurityEvents.Read.All / SecurityAlert.Read.All.
#>

function Invoke-SeguridadModule {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)] [hashtable]$Paths,
        [Parameter(Mandatory)] [string]$LogFile
    )

    $folder = $Paths.Security

    # --- Security Defaults --------------------------------------------
    try {
        Write-Log -Message 'Consultando Security Defaults...' -Level 'INFO' -LogFile $LogFile
        $secDefaults = Get-MgPolicyIdentitySecurityDefaultEnforcementPolicy -ErrorAction Stop
        [pscustomobject]@{ IsEnabled = $secDefaults.IsEnabled } |
            Export-ModuleResult -FolderPath $folder -FileName 'SecurityDefaults'
        Write-Log -Message "Security Defaults habilitados: $($secDefaults.IsEnabled)" -Level 'OK' -LogFile $LogFile
    }
    catch { Write-Log -Message "Error consultando Security Defaults: $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile }

    # --- Registro de métodos de autenticación (MFA) ---------------------
    try {
        Write-Log -Message 'Consultando estado de registro de MFA (Reports.Read.All)...' -Level 'INFO' -LogFile $LogFile
        $mfaReport = Get-MgReportAuthenticationMethodUserRegistrationDetail -All -ErrorAction Stop
        $mfaReport | Select-Object UserPrincipalName, IsMfaRegistered, IsMfaCapable, IsPasswordlessCapable, MethodsRegistered |
            Export-ModuleResult -FolderPath $folder -FileName 'MFA-RegistrationStatus'
        $notRegistered = ($mfaReport | Where-Object { -not $_.IsMfaRegistered }).Count
        Write-Log -Message "Usuarios evaluados: $($mfaReport.Count). Sin MFA registrado: $notRegistered" -Level 'OK' -LogFile $LogFile
    }
    catch { Write-Log -Message "Error consultando registro de MFA: $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile }

    # --- Secure Score ------------------------------------------------------
    try {
        Write-Log -Message 'Consultando Microsoft Secure Score...' -Level 'INFO' -LogFile $LogFile
        $secureScore = Get-MgSecuritySecureScore -Top 1 -ErrorAction Stop
        $secureScore | Select-Object Id, CurrentScore, MaxScore, CreatedDateTime |
            Export-ModuleResult -FolderPath $folder -FileName 'SecureScore' -AlsoJson
        if ($secureScore) {
            Write-Log -Message "Secure Score actual: $($secureScore.CurrentScore) / $($secureScore.MaxScore)" -Level 'OK' -LogFile $LogFile
        }
    }
    catch { Write-Log -Message "Error consultando Secure Score: $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile }

    # --- Alertas de seguridad recientes -------------------------------------
    try {
        Write-Log -Message 'Consultando alertas de seguridad recientes (Get-MgSecurityAlert_v2)...' -Level 'INFO' -LogFile $LogFile
        $alerts = Get-MgSecurityAlert_v2 -Top 50 -ErrorAction Stop
        $alerts | Select-Object Id, Title, Severity, Status, CreatedDateTime |
            Export-ModuleResult -FolderPath $folder -FileName 'SecurityAlerts'
        Write-Log -Message "Alertas de seguridad obtenidas: $($alerts.Count)" -Level 'OK' -LogFile $LogFile
    }
    catch { Write-Log -Message "Error consultando alertas de seguridad (requiere licencia de Defender/permiso adecuado): $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile }

    return $true
}
