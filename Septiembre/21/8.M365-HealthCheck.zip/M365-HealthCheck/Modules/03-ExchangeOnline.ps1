<#
.SYNOPSIS
    Módulo 03 - Exchange Online.
.DESCRIPTION
    IMPORTANTE: Microsoft Graph no expone toda la configuración de Exchange
    Online (reglas de transporte, conectores, buzones compartidos, etc.).
    Para esa información se sigue necesitando el módulo ExchangeOnlineManagement
    y Connect-ExchangeOnline, que este módulo maneja de forma independiente
    y opcional: si el módulo no está disponible o la conexión falla, el
    Health Check continúa con el resto de los módulos de Graph.
#>

function Invoke-ExchangeOnlineModule {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)] [hashtable]$Paths,
        [Parameter(Mandatory)] [string]$LogFile,
        [string]$UserPrincipalName
    )

    $folder = $Paths.Exchange

    $eomModule = Get-Module -ListAvailable -Name ExchangeOnlineManagement | Select-Object -First 1
    if (-not $eomModule) {
        Write-Log -Message 'El módulo ExchangeOnlineManagement no está instalado. Instálalo con: Install-Module ExchangeOnlineManagement -Scope CurrentUser. Se omite el módulo de Exchange Online.' -Level 'WARN' -LogFile $LogFile
        return $false
    }

    try {
        Import-Module ExchangeOnlineManagement -ErrorAction Stop

        $connectParams = @{ ShowBanner = $false }
        if ($UserPrincipalName) { $connectParams['UserPrincipalName'] = $UserPrincipalName }

        Write-Log -Message 'Conectando a Exchange Online (Connect-ExchangeOnline)...' -Level 'INFO' -LogFile $LogFile
        Connect-ExchangeOnline @connectParams -ErrorAction Stop
    }
    catch {
        Write-Log -Message "No se pudo conectar a Exchange Online: $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile
        return $false
    }

    try {
        Write-Log -Message 'Consultando configuración de la organización (Get-OrganizationConfig)...' -Level 'INFO' -LogFile $LogFile
        Get-OrganizationConfig | Select-Object Name, DisplayName, IsDehydrated, AllowedMailboxRegions |
            Export-ModuleResult -FolderPath $folder -FileName 'OrganizationConfig' -AlsoJson
    }
    catch { Write-Log -Message "Error en Get-OrganizationConfig: $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile }

    try {
        Write-Log -Message 'Consultando buzones (Get-Mailbox -ResultSize Unlimited)...' -Level 'INFO' -LogFile $LogFile
        $mailboxes = Get-Mailbox -ResultSize Unlimited -ErrorAction Stop
        $mailboxes | Select-Object DisplayName, PrimarySmtpAddress, RecipientTypeDetails, ArchiveStatus, LitigationHoldEnabled, ForwardingSmtpAddress |
            Export-ModuleResult -FolderPath $folder -FileName 'Mailboxes'
        Write-Log -Message "Buzones encontrados: $($mailboxes.Count)" -Level 'OK' -LogFile $LogFile
    }
    catch { Write-Log -Message "Error obteniendo buzones: $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile }

    try {
        Write-Log -Message 'Consultando reglas de transporte (Get-TransportRule)...' -Level 'INFO' -LogFile $LogFile
        $rules = Get-TransportRule -ErrorAction Stop
        $rules | Select-Object Name, State, Priority, Description |
            Export-ModuleResult -FolderPath $folder -FileName 'TransportRules'
        Write-Log -Message "Reglas de transporte encontradas: $($rules.Count)" -Level 'OK' -LogFile $LogFile
    }
    catch { Write-Log -Message "Error obteniendo reglas de transporte: $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile }

    try {
        Write-Log -Message 'Consultando conectores entrantes/salientes...' -Level 'INFO' -LogFile $LogFile
        $inbound = Get-InboundConnector -ErrorAction Stop
        $outbound = Get-OutboundConnector -ErrorAction Stop
        $inbound | Select-Object Name, Enabled, ConnectorType, SenderDomains | Export-ModuleResult -FolderPath $folder -FileName 'InboundConnectors'
        $outbound | Select-Object Name, Enabled, ConnectorType, RecipientDomains | Export-ModuleResult -FolderPath $folder -FileName 'OutboundConnectors'
        Write-Log -Message "Conectores entrantes: $($inbound.Count), salientes: $($outbound.Count)" -Level 'OK' -LogFile $LogFile
    }
    catch { Write-Log -Message "Error obteniendo conectores: $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile }

    try {
        Disconnect-ExchangeOnline -Confirm:$false -ErrorAction SilentlyContinue | Out-Null
        Write-Log -Message 'Sesión de Exchange Online cerrada.' -Level 'INFO' -LogFile $LogFile
    }
    catch { }

    return $true
}
