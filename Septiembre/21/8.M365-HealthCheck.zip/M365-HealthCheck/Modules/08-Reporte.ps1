<#
.SYNOPSIS
    Módulo 08 - Reporte.
.DESCRIPTION
    Consolida todos los CSV generados por los módulos anteriores en un único
    libro de Excel (Health Check.xlsx), un tab por CSV, usando el módulo
    ImportExcel (se instala automáticamente si falta). Si ImportExcel no se
    puede instalar (por ejemplo, sin salida a internet), se genera en su
    lugar un resumen consolidado en CSV como respaldo.
    También agrega un resumen del propio Health Check (módulos OK/ERROR,
    duración) a partir de $ModuleResults, generado por el orquestador.
#>

function Invoke-ReporteModule {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)] [hashtable]$Paths,
        [Parameter(Mandatory)] [string]$LogFile,
        [Parameter(Mandatory)] [array]$ModuleResults
    )

    $reportFolder = $Paths.Report

    # --- Resumen de ejecución del Health Check -----------------------------
    $ModuleResults | Export-ModuleResult -FolderPath $reportFolder -FileName 'ExecutionSummary' -AlsoJson
    Write-Log -Message 'Resumen de ejecución guardado en 08-Report\ExecutionSummary.csv' -Level 'INFO' -LogFile $LogFile

    # --- Recolectar todos los CSV generados por los demás módulos -----------
    $sourceFolders = $Paths.GetEnumerator() | Where-Object { $_.Key -ne 'Root' -and $_.Key -ne 'Report' }
    $csvFiles = foreach ($entry in $sourceFolders) {
        Get-ChildItem -Path $entry.Value -Filter '*.csv' -ErrorAction SilentlyContinue
    }

    if (-not $csvFiles) {
        Write-Log -Message 'No se encontraron archivos CSV de otros módulos para consolidar.' -Level 'WARN' -LogFile $LogFile
        return $true
    }

    # --- Intentar generar Health Check.xlsx con ImportExcel -----------------
    $importExcelAvailable = $null -ne (Get-Module -ListAvailable -Name ImportExcel | Select-Object -First 1)

    if (-not $importExcelAvailable) {
        try {
            Write-Log -Message 'Instalando módulo ImportExcel para generar el Excel consolidado...' -Level 'INFO' -LogFile $LogFile
            Install-Module ImportExcel -Scope CurrentUser -Force -ErrorAction Stop
            $importExcelAvailable = $true
        }
        catch {
            Write-Log -Message "No se pudo instalar ImportExcel: $($_.Exception.Message). Se generará solo un resumen en CSV." -Level 'WARN' -LogFile $LogFile
            $importExcelAvailable = $false
        }
    }

    if ($importExcelAvailable) {
        try {
            Import-Module ImportExcel -ErrorAction Stop
            $xlsxPath = Join-Path $reportFolder 'Health Check.xlsx'
            if (Test-Path $xlsxPath) { Remove-Item $xlsxPath -Force }

            foreach ($file in $csvFiles) {
                # Nombre de hoja: máx 31 caracteres, sin caracteres inválidos
                $sheetName = ($file.BaseName -replace '[\\/\?\*\[\]:]', '')
                if ($sheetName.Length -gt 31) { $sheetName = $sheetName.Substring(0, 31) }

                $data = Import-Csv -Path $file.FullName
                if ($data) {
                    $data | Export-Excel -Path $xlsxPath -WorksheetName $sheetName -AutoSize -TableStyle Medium2 -Append
                }
            }

            Write-Log -Message "Reporte consolidado generado: $xlsxPath" -Level 'OK' -LogFile $LogFile
        }
        catch {
            Write-Log -Message "Error generando Health Check.xlsx: $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile
        }
    }
    else {
        # --- Respaldo: un CSV índice que lista todos los archivos generados ---
        $index = $csvFiles | Select-Object @{N='Modulo';E={Split-Path (Split-Path $_.FullName -Parent) -Leaf}}, Name, FullName, Length, LastWriteTime
        $index | Export-ModuleResult -FolderPath $reportFolder -FileName 'FileIndex'
        Write-Log -Message 'Se generó un índice de archivos (FileIndex.csv) como respaldo del Excel consolidado.' -Level 'INFO' -LogFile $LogFile
    }

    return $true
}
