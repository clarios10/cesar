<#
.SYNOPSIS
    Módulo 07 - Aplicaciones (Microsoft Graph).
.DESCRIPTION
    Recolecta registros de aplicaciones (App Registrations), entidades de
    servicio (Enterprise Applications) y permisos delegados (OAuth2 grants).
    El detalle de app role assignments por SP es opcional (-IncludeAppRoles)
    porque puede ser lento en tenants grandes.
#>

function Invoke-AplicacionesModule {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)] [hashtable]$Paths,
        [Parameter(Mandatory)] [string]$LogFile,
        [switch]$IncludeAppRoles
    )

    $folder = $Paths.Applications

    # --- App Registrations --------------------------------------------
    try {
        Write-Log -Message 'Consultando App Registrations (Get-MgApplication)...' -Level 'INFO' -LogFile $LogFile
        $apps = Get-MgApplication -All -ErrorAction Stop
        $apps | Select-Object Id, AppId, DisplayName, SignInAudience, CreatedDateTime,
            @{N='HasClientSecrets';E={($_.PasswordCredentials).Count -gt 0}},
            @{N='HasCertificates';E={($_.KeyCredentials).Count -gt 0}} |
            Export-ModuleResult -FolderPath $folder -FileName 'AppRegistrations'
        Write-Log -Message "App Registrations encontradas: $($apps.Count)" -Level 'OK' -LogFile $LogFile
    }
    catch { Write-Log -Message "Error obteniendo App Registrations: $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile }

    # --- Service Principals (Enterprise Applications) -----------------------
    $sps = @()
    try {
        Write-Log -Message 'Consultando Service Principals (Get-MgServicePrincipal)...' -Level 'INFO' -LogFile $LogFile
        $sps = Get-MgServicePrincipal -All -ErrorAction Stop
        $sps | Select-Object Id, AppId, DisplayName, ServicePrincipalType, AccountEnabled, AppOwnerOrganizationId |
            Export-ModuleResult -FolderPath $folder -FileName 'ServicePrincipals'
        Write-Log -Message "Service Principals encontrados: $($sps.Count)" -Level 'OK' -LogFile $LogFile
    }
    catch { Write-Log -Message "Error obteniendo Service Principals: $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile }

    # --- Permisos delegados (OAuth2 permission grants) ----------------------
    try {
        Write-Log -Message 'Consultando permisos delegados (Get-MgOauth2PermissionGrant)...' -Level 'INFO' -LogFile $LogFile
        $grants = Get-MgOauth2PermissionGrant -All -ErrorAction Stop
        $grants | Select-Object Id, ClientId, ConsentType, ResourceId, Scope |
            Export-ModuleResult -FolderPath $folder -FileName 'OAuth2PermissionGrants'
        Write-Log -Message "Permisos delegados encontrados: $($grants.Count)" -Level 'OK' -LogFile $LogFile
    }
    catch { Write-Log -Message "Error obteniendo permisos delegados: $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile }

    # --- (Opcional) App role assignments por Service Principal --------------
    if ($IncludeAppRoles -and $sps) {
        try {
            Write-Log -Message 'Consultando app role assignments por Service Principal (puede tardar)...' -Level 'INFO' -LogFile $LogFile
            $appRoles = foreach ($sp in $sps) {
                $assignments = Get-MgServicePrincipalAppRoleAssignedTo -ServicePrincipalId $sp.Id -All -ErrorAction SilentlyContinue
                foreach ($a in $assignments) {
                    [pscustomobject]@{
                        ServicePrincipal = $sp.DisplayName
                        PrincipalType    = $a.PrincipalType
                        PrincipalName    = $a.PrincipalDisplayName
                        AppRoleId        = $a.AppRoleId
                    }
                }
            }
            $appRoles | Export-ModuleResult -FolderPath $folder -FileName 'AppRoleAssignments'
            Write-Log -Message "App role assignments encontrados: $($appRoles.Count)" -Level 'OK' -LogFile $LogFile
        }
        catch { Write-Log -Message "Error obteniendo app role assignments: $($_.Exception.Message)" -Level 'ERROR' -LogFile $LogFile }
    }

    return $true
}
