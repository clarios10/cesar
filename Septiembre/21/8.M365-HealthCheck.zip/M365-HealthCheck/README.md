# M365 Health Check — Scripts modulares (Microsoft.Graph)

Basado en la sección **"5. Ahora viene el Health Check"** del documento
`Pasos_para_preparar_el_ambiente`. Cada uno de los 8 módulos descritos ahí
es un archivo `.ps1` independiente, para que si uno falla no se pierda toda
la ejecución.

## Estructura

```
M365-HealthCheck/
├── M365-CloudOnly-HealthCheck.ps1   ← orquestador (ejecuta esto)
├── Common/
│   └── Common-Functions.ps1         ← logging, carpetas, export CSV/JSON
└── Modules/
    ├── 01-Conexion.ps1              ← valida PS7, módulo Graph, conecta, prueba Get-MgUser
    ├── 02-EntraID.ps1               ← organización, dominios, usuarios, grupos, roles, CA policies
    ├── 03-ExchangeOnline.ps1        ← buzones, reglas de transporte, conectores (requiere ExchangeOnlineManagement)
    ├── 04-Seguridad.ps1             ← Security Defaults, registro MFA, Secure Score, alertas
    ├── 05-Compliance.ps1            ← etiquetas de sensibilidad (Graph) + retención/DLP (opcional, IPPS)
    ├── 06-Licenciamiento.ps1        ← SKUs y licencias asignadas por usuario
    ├── 07-Aplicaciones.ps1          ← App Registrations, Enterprise Apps, permisos delegados
    └── 08-Reporte.ps1               ← consolida todos los CSV en "Health Check.xlsx"
```

Al ejecutarse, se crea automáticamente:

```
C:\M365-HealthCheck\<fecha_hora>\
├── 00-Execution   (log, contexto de conexión, resumen de ejecución)
├── 01-Exchange
├── 02-EntraID-Graph
├── 03-Security
├── 04-Compliance
├── 05-Licensing
├── 06-Applications
├── 07-DNS         (reservada; no usada por estos módulos aún)
└── 08-Report      (Health Check.xlsx)
```

Cada ejecución queda en su propia carpeta con fecha/hora, para poder
comparar Fase 0 (Baseline) vs. Fase 3 (Post-Cutover), etc.

## Requisitos previos

```powershell
Install-Module Microsoft.Graph -Scope CurrentUser
# Opcional, para los módulos 03 y 05:
Install-Module ExchangeOnlineManagement -Scope CurrentUser
# Opcional, para el reporte consolidado en Excel (se instala solo si falta):
Install-Module ImportExcel -Scope CurrentUser
```

Si `Set-ExecutionPolicy` bloquea la ejecución (ver sección 8 del documento):

```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```

## Uso

**Recomendado (siguiendo el documento): primero solo el módulo de Conexión**

```powershell
cd C:\M365-HealthCheck
Import-Module .\Common\Common-Functions.ps1
. .\Modules\01-Conexion.ps1
$Paths = Initialize-HealthCheckFolders
$LogFile = Join-Path $Paths.Execution 'test.log'
Invoke-ConexionModule -Scopes @('User.Read.All','Group.Read.All','Directory.Read.All','RoleManagement.Read.Directory') -Paths $Paths -LogFile $LogFile
```

**Ejecución completa (todos los módulos, por el orquestador):**

```powershell
.\M365-CloudOnly-HealthCheck.ps1
```

**Parámetros útiles:**

```powershell
# Sin Exchange Online (solo Graph)
.\M365-CloudOnly-HealthCheck.ps1 -SkipExchangeOnline

# Sin Compliance Center (Connect-IPPSSession), solo lo que da Graph
.\M365-CloudOnly-HealthCheck.ps1 -SkipComplianceCenter

# Carpeta base distinta
.\M365-CloudOnly-HealthCheck.ps1 -BasePath 'D:\Proyectos\ClienteX\HealthCheck'

# Incluir detalle de app role assignments (más lento)
.\M365-CloudOnly-HealthCheck.ps1 -IncludeAppRoleAssignments
```

## Notas importantes

- **El módulo 01-Conexión es obligatorio.** Si falla, el orquestador detiene
  todo el Health Check porque los demás módulos dependen de esa sesión.
- **Los módulos 02, 04, 06 y 07 son 100% Microsoft.Graph.**
- **Los módulos 03 y 05 necesitan además `ExchangeOnlineManagement`**
  (Connect-ExchangeOnline / Connect-IPPSSession), porque Microsoft Graph no
  expone toda esa configuración todavía. Si el módulo no está instalado o
  la conexión falla, esos módulos se omiten con una advertencia y el resto
  del Health Check continúa.
- Cada módulo usa `Write-Log` para escribir en consola y en
  `00-Execution\HealthCheck.log`, y `Export-ModuleResult` para guardar cada
  resultado en CSV (y JSON cuando aplica).
- Si `Need admin approval` aparece al conectar, no es un error del script:
  significa que el tenant requiere consentimiento de administrador para
  alguno de los scopes solicitados (ver sección 9 del documento).

## Siguiente paso sugerido

Confirma que `Invoke-ConexionModule` corre sin errores y que
`Get-MgUser -Top 10` devuelve usuarios reales de tu tenant de prueba. Con
eso confirmado, el resto de los módulos (02 a 08) ya están listos para
correr contra el tenant del cliente.
