#Requires -Version 7.0
<#
.SYNOPSIS
    M365 Health Check - Orquestador principal.
.DESCRIPTION
    Ejecuta el Health Check de Microsoft 365 por módulos independientes,
    siguiendo el flujo descrito en la sección 11 del documento:

        Validar PowerShell 7 -> Validar módulos -> Crear estructura de
        carpetas -> Conectar Graph -> (Conectar Exchange) ->
        01-Conexión -> 02-EntraID -> 03-ExchangeOnline -> 04-Seguridad ->
        05-Compliance -> 06-Licenciamiento -> 07-Aplicaciones -> 08-Reporte

    Si un módulo falla, se registra el error y se continúa con el siguiente
    (no se pierde toda la ejecución del Health Check por un solo módulo),
    excepto el módulo de Conexión: si éste falla, se detiene todo, porque
    los demás módulos dependen de la sesión de Microsoft Graph.

    Cada ejecución crea su propia carpeta con fecha/hora
    (C:\M365-HealthCheck\2026-09-21_101500\...) para poder comparar
    ejecuciones entre fases del proyecto (Fase 0 - Baseline, Fase 3 -
    Post-Cutover, Fase 4 - Post-Remediación, etc.).

.PARAMETER BasePath
    Carpeta base donde se crean las carpetas de cada ejecución.
    Por defecto: C:\M365-HealthCheck

.PARAMETER Scopes
    Scopes de Microsoft Graph a solicitar en Connect-MgGraph.

.PARAMETER SkipExchangeOnline
    Omite el módulo 03 - Exchange Online (por si solo se quiere correr
    la parte de Microsoft Graph).

.PARAMETER SkipCompliance
    Omite por completo el módulo 05 - Compliance.

.PARAMETER SkipComplianceCenter
    Ejecuta el módulo 05 pero omite el bloque opcional de Security &
    Compliance Center (Connect-IPPSSession); solo consulta lo que expone
    Microsoft Graph.

.PARAMETER IncludeAppRoleAssignments
    Incluye el detalle de app role assignments por Service Principal en el
    módulo 07 - Aplicaciones (puede ser lento en tenants grandes).

.EXAMPLE
    .\M365-CloudOnly-HealthCheck.ps1

.EXAMPLE
    .\M365-CloudOnly-HealthCheck.ps1 -BasePath 'C:\M365-HealthCheck' -SkipExchangeOnline
#>

[CmdletBinding()]
param(
    [string]$BasePath = 'C:\M365-HealthCheck',

    [string[]]$Scopes = @(
        'User.Read.All',
        'Group.Read.All',
        'Directory.Read.All',
        'RoleManagement.Read.Directory',
        'Policy.Read.All',
        'Reports.Read.All',
        'SecurityEvents.Read.All',
        'Organization.Read.All',
        'Application.Read.All',
        'InformationProtectionPolicy.Read'
    ),

    [switch]$SkipExchangeOnline,
    [switch]$SkipCompliance,
    [switch]$SkipComplianceCenter,
    [switch]$IncludeAppRoleAssignments,
    [string]$ExchangeUserPrincipalName
)

$ErrorActionPreference = 'Stop'

# ------------------------------------------------------------------
# 0. Cargar funciones comunes y módulos
# ------------------------------------------------------------------
$scriptRoot = $PSScriptRoot
. (Join-Path $scriptRoot 'Common\Common-Functions.ps1')
. (Join-Path $scriptRoot 'Modules\01-Conexion.ps1')
. (Join-Path $scriptRoot 'Modules\02-EntraID.ps1')
. (Join-Path $scriptRoot 'Modules\03-ExchangeOnline.ps1')
. (Join-Path $scriptRoot 'Modules\04-Seguridad.ps1')
. (Join-Path $scriptRoot 'Modules\05-Compliance.ps1')
. (Join-Path $scriptRoot 'Modules\06-Licenciamiento.ps1')
. (Join-Path $scriptRoot 'Modules\07-Aplicaciones.ps1')
. (Join-Path $scriptRoot 'Modules\08-Reporte.ps1')

# ------------------------------------------------------------------
# 1. Crear estructura de carpetas para esta ejecución
# ------------------------------------------------------------------
$Paths = Initialize-HealthCheckFolders -BasePath $BasePath
$LogFile = Join-Path $Paths.Execution 'HealthCheck.log'

Write-Log -Message '========================================================' -Level 'INFO' -LogFile $LogFile
Write-Log -Message "M365 Health Check iniciado. Carpeta de ejecución: $($Paths.Root)" -Level 'INFO' -LogFile $LogFile
Write-Log -Message '========================================================' -Level 'INFO' -LogFile $LogFile

$ModuleResults = @()

# ------------------------------------------------------------------
# 2. Módulo 01 - Conexión (obligatorio; si falla, se detiene todo)
# ------------------------------------------------------------------
$conexionResult = Invoke-HealthCheckModule -Name '01-Conexion' -LogFile $LogFile -ScriptBlock {
    Invoke-ConexionModule -Scopes $Scopes -Paths $Paths -LogFile $LogFile | Out-Null
}
$ModuleResults += $conexionResult

if ($conexionResult.Status -ne 'OK') {
    Write-Log -Message 'El módulo de Conexión falló. Se detiene el Health Check: los demás módulos requieren la sesión de Microsoft Graph.' -Level 'ERROR' -LogFile $LogFile
    $ModuleResults | Export-ModuleResult -FolderPath $Paths.Report -FileName 'ExecutionSummary'
    return
}

# ------------------------------------------------------------------
# 3. Módulos independientes (si uno falla, se continúa con el siguiente)
# ------------------------------------------------------------------
$ModuleResults += Invoke-HealthCheckModule -Name '02-EntraID' -LogFile $LogFile -ScriptBlock {
    Invoke-EntraIDModule -Paths $Paths -LogFile $LogFile | Out-Null
}

if (-not $SkipExchangeOnline) {
    $ModuleResults += Invoke-HealthCheckModule -Name '03-ExchangeOnline' -LogFile $LogFile -ScriptBlock {
        Invoke-ExchangeOnlineModule -Paths $Paths -LogFile $LogFile -UserPrincipalName $ExchangeUserPrincipalName | Out-Null
    }
}
else {
    Write-Log -Message 'Módulo 03-ExchangeOnline omitido (-SkipExchangeOnline).' -Level 'WARN' -LogFile $LogFile
}

$ModuleResults += Invoke-HealthCheckModule -Name '04-Seguridad' -LogFile $LogFile -ScriptBlock {
    Invoke-SeguridadModule -Paths $Paths -LogFile $LogFile | Out-Null
}

if (-not $SkipCompliance) {
    $ModuleResults += Invoke-HealthCheckModule -Name '05-Compliance' -LogFile $LogFile -ScriptBlock {
        Invoke-ComplianceModule -Paths $Paths -LogFile $LogFile -SkipIPPS:$SkipComplianceCenter | Out-Null
    }
}
else {
    Write-Log -Message 'Módulo 05-Compliance omitido (-SkipCompliance).' -Level 'WARN' -LogFile $LogFile
}

$ModuleResults += Invoke-HealthCheckModule -Name '06-Licenciamiento' -LogFile $LogFile -ScriptBlock {
    Invoke-LicenciamientoModule -Paths $Paths -LogFile $LogFile | Out-Null
}

$ModuleResults += Invoke-HealthCheckModule -Name '07-Aplicaciones' -LogFile $LogFile -ScriptBlock {
    Invoke-AplicacionesModule -Paths $Paths -LogFile $LogFile -IncludeAppRoles:$IncludeAppRoleAssignments | Out-Null
}

# ------------------------------------------------------------------
# 4. Módulo 08 - Reporte (consolida todo lo anterior)
# ------------------------------------------------------------------
$ModuleResults += Invoke-HealthCheckModule -Name '08-Reporte' -LogFile $LogFile -ScriptBlock {
    Invoke-ReporteModule -Paths $Paths -LogFile $LogFile -ModuleResults $ModuleResults | Out-Null
}

# ------------------------------------------------------------------
# 5. Resumen final en consola
# ------------------------------------------------------------------
Write-Log -Message '========================================================' -Level 'INFO' -LogFile $LogFile
Write-Log -Message 'Resumen de ejecución:' -Level 'INFO' -LogFile $LogFile
foreach ($r in $ModuleResults) {
    $level = if ($r.Status -eq 'OK') { 'OK' } else { 'ERROR' }
    Write-Log -Message ("  {0,-20} {1,-6} ({2}s)" -f $r.Module, $r.Status, $r.DurationSec) -Level $level -LogFile $LogFile
}
Write-Log -Message "Health Check finalizado. Resultados en: $($Paths.Root)" -Level 'OK' -LogFile $LogFile
Write-Log -Message '========================================================' -Level 'INFO' -LogFile $LogFile

Disconnect-MgGraph -ErrorAction SilentlyContinue | Out-Null
