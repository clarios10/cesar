// ============================================================================
// main.bicep
// Despliegue de la Arquitectura de 3 Niveles en Azure (IaaS)
// Basado en: "Propuesta Arquitectura Azure 3Niveles.docx" — Sección 11
//            (Estimación de Costos / SKUs) y Secciones 4, 7 y 12
//
// Recursos desplegados (según hoja de costos 0_1-Info_Infra_01.csv):
//   - VM Servidor de Aplicación .... Standard DC16ds_v3 (16 vCPU/128GB)
//   - VM Servidor de Base de Datos . Standard D8as_v5   (8 vCPU/32GB) + SQL Server Standard (PAYG)
//   - Discos administrados ......... Premium SSD (OS 512GB / App 1TB / Logs 512GB / BD 2TB)
//   - Application Gateway .......... WAF_v2 (Estándar V2) + 1 IP Pública dedicada
//   - Azure VPN Gateway (S2S) ...... VpnGw1 (OPCIONAL — deployVpnGateway)
//   - Azure Bastion ................ Basic SKU (OPCIONAL — deployBastion)
//   - Azure Backup / Recovery Vault . LRS
//   - Azure Monitor / Log Analytics . 10 GB/día de ingesta
//
// Uso:
//   az deployment group create \
//     --resource-group rg-contoso-app-prod \
//     --template-file main.bicep \
//     --parameters main.bicepparam
// ============================================================================

targetScope = 'resourceGroup'

@description('Prefijo corto para nombrar todos los recursos (ej. "contoso")')
@minLength(3)
@maxLength(12)
param namePrefix string

@description('Región de despliegue de Azure')
param location string = resourceGroup().location

@description('Usuario administrador local para ambas VMs')
param adminUsername string

@description('Contraseña del administrador local (pasar como parámetro seguro / Key Vault reference, nunca en texto plano)')
@secure()
param adminPassword string

@description('Resource Id del secreto en Key Vault con el certificado TLS (pfx) para el listener HTTPS del Application Gateway')
@secure()
param sslCertKeyVaultSecretId string

@description('Resource Id de la identidad administrada (User Assigned) con permiso de lectura sobre el Key Vault del certificado')
param managedIdentityId string

@description('FQDN o IP privada del servidor de Aplicación usado como backend del Application Gateway (por defecto se autocompone desde la VM desplegada)')
param appBackendOverrideFqdn string = ''

@description('Desplegar Azure VPN Gateway (Site-to-Site) — Sección 12.3: componente OPCIONAL/recomendado')
param deployVpnGateway bool = true

@description('Desplegar Azure Bastion — Sección 12.2/12.3: componente OPCIONAL/recomendado')
param deployBastion bool = true

@description('Modalidad de licenciamiento SQL Server: PAYG o AHUB (Azure Hybrid Benefit). Sección 11: AHUB puede reducir el costo hasta 55%.')
@allowed([
  'PAYG'
  'AHUB'
])
param sqlLicenseType string = 'PAYG'

@description('IPs públicas de los dispositivos VPN de cada sucursal (solo si deployVpnGateway = true)')
param branchGatewayIps array = []

@description('Rangos de red de cada sucursal (solo si deployVpnGateway = true)')
param branchAddressPrefixes array = []

@description('Clave compartida (PSK) del túnel IPsec (solo si deployVpnGateway = true)')
@secure()
param vpnSharedKey string = ''

@description('Email de notificación para las alertas de Azure Monitor')
param alertEmail string

@description('Tags corporativos a aplicar a todos los recursos')
param tags object = {
  Proyecto: 'Solucion-Web-3Niveles'
  Ambiente: 'Produccion'
  Propuesta: 'Propuesta Arquitectura Azure 3Niveles'
}

// ----------------------------------------------------------------------------
// 1. Red: VNet, subredes y NSGs (Secciones 4 y 7.3)
// ----------------------------------------------------------------------------
module network 'modules/network.bicep' = {
  name: 'deploy-network'
  params: {
    namePrefix: namePrefix
    location: location
    deployVpnGateway: deployVpnGateway
    deployBastion: deployBastion
    tags: tags
  }
}

// ----------------------------------------------------------------------------
// 2. VM Servidor de Aplicación (Sección 7.1) — Standard DC16ds_v3
// ----------------------------------------------------------------------------
module vmApp 'modules/vmApp.bicep' = {
  name: 'deploy-vm-app'
  params: {
    namePrefix: namePrefix
    location: location
    subnetId: network.outputs.snetAppId
    adminUsername: adminUsername
    adminPassword: adminPassword
    tags: tags
  }
}

// ----------------------------------------------------------------------------
// 3. VM Servidor de Base de Datos (Sección 7.2) — Standard D8as_v5 + SQL Server
// ----------------------------------------------------------------------------
module vmDb 'modules/vmDb.bicep' = {
  name: 'deploy-vm-db'
  params: {
    namePrefix: namePrefix
    location: location
    subnetId: network.outputs.snetDbId
    adminUsername: adminUsername
    adminPassword: adminPassword
    sqlLicenseType: sqlLicenseType
    tags: tags
  }
}

// ----------------------------------------------------------------------------
// 4. Application Gateway WAF_v2 + IP Pública (Secciones 4.1, 4.1.1, 12.1)
// ----------------------------------------------------------------------------
module appGateway 'modules/appGateway.bicep' = {
  name: 'deploy-appgw'
  params: {
    namePrefix: namePrefix
    location: location
    subnetId: network.outputs.snetAppGwId
    backendFqdnOrIp: empty(appBackendOverrideFqdn) ? vmApp.outputs.privateIp : appBackendOverrideFqdn
    sslCertKeyVaultSecretId: sslCertKeyVaultSecretId
    managedIdentityId: managedIdentityId
    tags: tags
  }
}

// ----------------------------------------------------------------------------
// 5. Azure Bastion (opcional) — Sección 7.3 / 12.2
// ----------------------------------------------------------------------------
module bastion 'modules/bastion.bicep' = if (deployBastion) {
  name: 'deploy-bastion'
  params: {
    namePrefix: namePrefix
    location: location
    bastionSubnetId: network.outputs.snetBastionId
    tags: tags
  }
}

// ----------------------------------------------------------------------------
// 6. Azure VPN Gateway Site-to-Site (opcional) — Sección 4.1.2 / 12.3
// ----------------------------------------------------------------------------
module vpnGateway 'modules/vpnGateway.bicep' = if (deployVpnGateway) {
  name: 'deploy-vpngw'
  params: {
    namePrefix: namePrefix
    location: location
    gatewaySubnetId: network.outputs.snetGatewayId
    branchGatewayIps: branchGatewayIps
    branchAddressPrefixes: branchAddressPrefixes
    sharedKey: vpnSharedKey
    tags: tags
  }
}

// ----------------------------------------------------------------------------
// 7. Monitoreo: Log Analytics + Alertas (Sección 4.6 / 11)
// ----------------------------------------------------------------------------
module monitoring 'modules/monitoring.bicep' = {
  name: 'deploy-monitoring'
  params: {
    namePrefix: namePrefix
    location: location
    vmResourceIds: [
      vmApp.outputs.vmId
      vmDb.outputs.vmId
    ]
    alertEmail: alertEmail
    tags: tags
  }
}

// ----------------------------------------------------------------------------
// 8. Backup: Recovery Services Vault + Política (Sección 4.6 / 11)
// ----------------------------------------------------------------------------
module backup 'modules/backup.bicep' = {
  name: 'deploy-backup'
  params: {
    namePrefix: namePrefix
    location: location
    vmsToProtect: [
      {
        vmId: vmApp.outputs.vmId
        vmName: vmApp.outputs.vmName
      }
      {
        vmId: vmDb.outputs.vmId
        vmName: vmDb.outputs.vmName
      }
    ]
    tags: tags
  }
}

// ----------------------------------------------------------------------------
// Outputs
// ----------------------------------------------------------------------------
output applicationPublicIp string = appGateway.outputs.publicIpAddress
output applicationPublicFqdn string = appGateway.outputs.publicIpFqdn
output vmAppPrivateIp string = vmApp.outputs.privateIp
output vmDbPrivateIp string = vmDb.outputs.privateIp
output vnetName string = network.outputs.vnetName
output recoveryVaultId string = backup.outputs.vaultId
output logAnalyticsWorkspaceId string = monitoring.outputs.logAnalyticsWorkspaceId
