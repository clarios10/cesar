// ============================================================================
// modules/vmDb.bicep
// VM Servidor de Base de Datos — Sección 7.2 de la propuesta
// SKU: Standard D8as_v5 (8 vCPU / 32 GB RAM) — según hoja de costos
// (0_1-Info_Infra_01.csv): "1 D8as v5 (8 vCPUs, 32 GB RAM) x 730 Horas
// (Pay as you go), Windows (Licencia incluida), SQL Standard (Pay as you go)"
// Windows Server 2025 + SQL Server Standard, disco OS 512GB + BD 2TB + Logs 512GB
// ============================================================================

@description('Prefijo de nombre para los recursos')
param namePrefix string

@description('Región de despliegue')
param location string

@description('Id de la subred de Base de Datos (VLAN BD aislada)')
param subnetId string

@description('Tamaño de VM — por defecto Standard_D8as_v5 (8 vCPU/32GB), según hoja de costos de infraestructura')
param vmSize string = 'Standard_D8as_v5'

@description('Nombre de usuario administrador local')
param adminUsername string

@description('Contraseña del administrador local (usar Key Vault reference en el parámetro, nunca texto plano en el repositorio)')
@secure()
param adminPassword string

@description('Modalidad de licenciamiento SQL Server: PAYG (incluida en el precio) o AHUB (Azure Hybrid Benefit, requiere Software Assurance). Sección 11: AHUB puede reducir el costo hasta 55%.')
@allowed([
  'PAYG'
  'AHUB'
])
param sqlLicenseType string = 'PAYG'

@description('Imagen de marketplace SQL Server sobre Windows Server. Ajustar según disponibilidad regional de la edición SQL Server 2025 al momento del despliegue.')
param sqlImageReference object = {
  publisher: 'MicrosoftSQLServer'
  offer: 'sql2022-ws2025'
  sku: 'standard-gen2'
  version: 'latest'
}

@description('Tags a aplicar')
param tags object = {}

// ----------------------------------------------------------------------------
// NIC — sin IP pública, solo alcanzable desde la subred de Aplicación (Sección 4.3)
// ----------------------------------------------------------------------------
resource nicDb 'Microsoft.Network/networkInterfaces@2023-09-01' = {
  name: '${namePrefix}-db-nic'
  location: location
  tags: tags
  properties: {
    ipConfigurations: [
      {
        name: 'ipconfig1'
        properties: {
          privateIPAllocationMethod: 'Dynamic'
          subnet: {
            id: subnetId
          }
        }
      }
    ]
  }
}

// ----------------------------------------------------------------------------
// VM Servidor de Base de Datos
// Discos: OS 512GB, BD 2TB (LUN 0), Logs 512GB (LUN 1) — Premium SSD (Sección 7.2)
// ----------------------------------------------------------------------------
resource vmDb 'Microsoft.Compute/virtualMachines@2023-09-01' = {
  name: '${namePrefix}-vm-db'
  location: location
  tags: union(tags, {
    Rol: 'ServidorBaseDeDatos'
  })
  properties: {
    hardwareProfile: {
      vmSize: vmSize
    }
    osProfile: {
      computerName: 'vm-db-01'
      adminUsername: adminUsername
      adminPassword: adminPassword
      windowsConfiguration: {
        enableAutomaticUpdates: true
        patchSettings: {
          patchMode: 'AutomaticByOS'
        }
      }
    }
    storageProfile: {
      imageReference: sqlImageReference
      osDisk: {
        name: '${namePrefix}-db-osdisk'
        createOption: 'FromImage'
        diskSizeGB: 512
        managedDisk: {
          storageAccountType: 'Premium_LRS'
        }
      }
      dataDisks: [
        {
          name: '${namePrefix}-db-datadisk-data'
          lun: 0
          createOption: 'Empty'
          diskSizeGB: 2048
          managedDisk: {
            storageAccountType: 'Premium_LRS'
          }
          caching: 'ReadOnly'
        }
        {
          name: '${namePrefix}-db-datadisk-logs'
          lun: 1
          createOption: 'Empty'
          diskSizeGB: 512
          managedDisk: {
            storageAccountType: 'Premium_LRS'
          }
          caching: 'None'
        }
      ]
    }
    networkProfile: {
      networkInterfaces: [
        {
          id: nicDb.id
        }
      ]
    }
  }
}

// Extensión de diagnóstico/monitoreo básico (Azure Monitor Agent)
resource amaDb 'Microsoft.Compute/virtualMachines/extensions@2023-09-01' = {
  parent: vmDb
  name: 'AzureMonitorWindowsAgent'
  location: location
  properties: {
    publisher: 'Microsoft.Azure.Monitor'
    type: 'AzureMonitorWindowsAgent'
    typeHandlerVersion: '1.0'
    autoUpgradeMinorVersion: true
  }
}

// ----------------------------------------------------------------------------
// Recurso SQL Virtual Machine — registra la VM ante el proveedor SQL IaaS de
// Azure: habilita licenciamiento AHUB/PAYG, backups automatizados y patching
// administrado (Sección 4.6 / 11 de la propuesta)
// ----------------------------------------------------------------------------
resource sqlVm 'Microsoft.SqlVirtualMachine/sqlVirtualMachines@2023-10-01' = {
  name: vmDb.name
  location: location
  tags: tags
  properties: {
    virtualMachineResourceId: vmDb.id
    sqlServerLicenseType: sqlLicenseType
    sqlManagement: 'Full'
    storageConfigurationSettings: {
      diskConfigurationType: 'NEW'
      storageWorkloadType: 'OLTP'
      sqlDataSettings: {
        luns: [0]
        defaultFilePath: 'F:\\SQLData'
      }
      sqlLogSettings: {
        luns: [1]
        defaultFilePath: 'G:\\SQLLog'
      }
    }
    autoPatchingSettings: {
      enable: true
      dayOfWeek: 'Sunday'
      maintenanceWindowStartingHour: 2
      maintenanceWindowDuration: 60
    }
  }
}

output vmId string = vmDb.id
output vmName string = vmDb.name
output nicId string = nicDb.id
output privateIp string = nicDb.properties.ipConfigurations[0].properties.privateIPAddress
