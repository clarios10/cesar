// ============================================================================
// modules/bastion.bicep
// Azure Bastion (Basic SKU) — según hoja de costos (0_1-Info_Infra_01.csv):
// "Nivel Basic, 730 Horas, 5 GB Transferencia de datos de salida"
// Acceso administrativo RDP/SSH vía Azure Portal (HTTPS 443), sin exponer
// puertos de gestión a Internet. Alternativa/complemento a TC Plus.
// NOTA: el SKU Basic no soporta Native Client Support / túnel (enableTunneling),
// escalado por host ni Shareable Port; si se requieren esas capacidades hay que
// pasar a Standard, lo que incrementa el costo estimado en el CSV.
// ============================================================================

@description('Prefijo de nombre para los recursos')
param namePrefix string

@description('Región de despliegue')
param location string

@description('Id de la subred AzureBastionSubnet (nombre reservado, mínimo /26)')
param bastionSubnetId string

@description('Tags a aplicar')
param tags object = {}

resource pipBastion 'Microsoft.Network/publicIPAddresses@2023-09-01' = {
  name: '${namePrefix}-pip-bastion'
  location: location
  tags: tags
  sku: {
    name: 'Standard'
  }
  properties: {
    publicIPAllocationMethod: 'Static'
  }
}

resource bastion 'Microsoft.Network/bastionHosts@2023-09-01' = {
  name: '${namePrefix}-bastion'
  location: location
  tags: tags
  sku: {
    name: 'Basic'
  }
  properties: {
    enableTunneling: false
    ipConfigurations: [
      {
        name: 'bastionIpConfig'
        properties: {
          subnet: {
            id: bastionSubnetId
          }
          publicIPAddress: {
            id: pipBastion.id
          }
        }
      }
    ]
  }
}

output bastionId string = bastion.id
