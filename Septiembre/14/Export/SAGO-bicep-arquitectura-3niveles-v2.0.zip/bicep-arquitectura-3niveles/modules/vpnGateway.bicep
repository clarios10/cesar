// ============================================================================
// modules/vpnGateway.bicep
// Azure VPN Gateway (Site-to-Site) — Sección 4.1.2, 7.3 y 12.3 de la propuesta
// SKU: VpnGw1 (referencial). Componente OPCIONAL/RECOMENDADO para
// conectividad administrativa privada sucursales <-> Azure.
// ============================================================================

@description('Prefijo de nombre para los recursos')
param namePrefix string

@description('Región de despliegue')
param location string

@description('Id de GatewaySubnet (nombre reservado por Azure)')
param gatewaySubnetId string

@description('SKU del VPN Gateway — VpnGw1 según Sección 11 de la propuesta')
@allowed([
  'VpnGw1'
  'VpnGw2'
  'VpnGw3'
])
param vpnGatewaySku string = 'VpnGw1'

@description('Direcciones IP públicas de los dispositivos VPN de cada sucursal (extremo remoto del túnel S2S)')
param branchGatewayIps array = []

@description('Rangos de direcciones IP de cada sucursal (para el routing del túnel)')
param branchAddressPrefixes array = []

@description('Clave compartida (PSK) del túnel IPsec — proveer vía parámetro seguro/Key Vault en tiempo de despliegue')
@secure()
param sharedKey string

@description('Tags a aplicar')
param tags object = {}

resource pipVpnGw 'Microsoft.Network/publicIPAddresses@2023-09-01' = {
  name: '${namePrefix}-pip-vpngw'
  location: location
  tags: tags
  sku: {
    name: 'Standard'
  }
  properties: {
    publicIPAllocationMethod: 'Static'
  }
}

resource vpnGateway 'Microsoft.Network/virtualNetworkGateways@2023-09-01' = {
  name: '${namePrefix}-vpngw'
  location: location
  tags: tags
  properties: {
    gatewayType: 'Vpn'
    vpnType: 'RouteBased'
    sku: {
      name: vpnGatewaySku
      tier: vpnGatewaySku
    }
    ipConfigurations: [
      {
        name: 'vnetGatewayConfig'
        properties: {
          privateIPAllocationMethod: 'Dynamic'
          subnet: {
            id: gatewaySubnetId
          }
          publicIPAddress: {
            id: pipVpnGw.id
          }
        }
      }
    ]
  }
}

// Un Local Network Gateway + Connection por cada sucursal (Sección 7.3:
// "1 túnel por sucursal, a confirmar"). Se crea uno por cada IP en branchGatewayIps.
resource localGateways 'Microsoft.Network/localNetworkGateways@2023-09-01' = [for (ip, i) in branchGatewayIps: {
  name: '${namePrefix}-lng-sucursal-${i + 1}'
  location: location
  tags: tags
  properties: {
    gatewayIpAddress: ip
    localNetworkAddressSpace: {
      addressPrefixes: [
        branchAddressPrefixes[i]
      ]
    }
  }
}]

resource connections 'Microsoft.Network/connections@2023-09-01' = [for (ip, i) in branchGatewayIps: {
  name: '${namePrefix}-conn-sucursal-${i + 1}'
  location: location
  tags: tags
  properties: {
    connectionType: 'IPsec'
    virtualNetworkGateway1: {
      id: vpnGateway.id
      properties: {}
    }
    localNetworkGateway2: {
      id: localGateways[i].id
      properties: {}
    }
    sharedKey: sharedKey
    connectionProtocol: 'IKEv2'
  }
}]

output vpnGatewayId string = vpnGateway.id
output vpnGatewayPublicIp string = pipVpnGw.properties.ipAddress
