// ============================================================================
// modules/appGateway.bicep
// Azure Application Gateway (WAF_v2) + 1 IP Pública dedicada
// Conforme a Secciones 4.1, 4.1.1, 7.3 y 12.1 de la propuesta:
//  - WAF_v2 (no "Basic" v1, que Microsoft retira en abril 2026)
//  - 1 sola IP Pública Standard, asignada exclusivamente a este recurso
// ============================================================================

@description('Prefijo de nombre para los recursos')
param namePrefix string

@description('Región de despliegue')
param location string

@description('Id de la subred dedicada al Application Gateway')
param subnetId string

@description('FQDN/dominio de la aplicación (para el backend pool / probe). Ajustar según DNS real del App Server')
param backendFqdnOrIp string

@description('Puerto del backend (servidor de Aplicación, IIS)')
param backendPort int = 443

@description('Capacidad mínima de autoescalado del WAF_v2')
param autoscaleMinCapacity int = 1

@description('Capacidad máxima de autoescalado del WAF_v2')
param autoscaleMaxCapacity int = 3

@description('Resource Id del secreto en Key Vault que contiene el certificado TLS (pfx) para el listener HTTPS. Debe existir antes de desplegar.')
@secure()
param sslCertKeyVaultSecretId string

@description('Resource Id de la identidad administrada (User Assigned) con permiso "Get" sobre secretos del Key Vault del certificado')
param managedIdentityId string

@description('Tags a aplicar')
param tags object = {}

// ----------------------------------------------------------------------------
// IP Pública — 1 sola, Standard, estática, zona-redundante (Sección 4.1.1)
// ----------------------------------------------------------------------------
resource pipAppGw 'Microsoft.Network/publicIPAddresses@2023-09-01' = {
  name: '${namePrefix}-pip-appgw'
  location: location
  tags: tags
  sku: {
    name: 'Standard'
    tier: 'Regional'
  }
  zones: [
    '1'
    '2'
    '3'
  ]
  properties: {
    publicIPAllocationMethod: 'Static'
    dnsSettings: {
      domainNameLabel: '${namePrefix}-app'
    }
  }
}

// ----------------------------------------------------------------------------
// Política WAF — OWASP Core Rule Set, modo Prevention (bloqueo activo)
// ----------------------------------------------------------------------------
resource wafPolicy 'Microsoft.Network/ApplicationGatewayWebApplicationFirewallPolicies@2023-09-01' = {
  name: '${namePrefix}-wafpolicy'
  location: location
  tags: tags
  properties: {
    policySettings: {
      state: 'Enabled'
      mode: 'Prevention'
      requestBodyCheck: true
      maxRequestBodySizeInKb: 128
      fileUploadLimitInMb: 100
    }
    managedRules: {
      managedRuleSets: [
        {
          ruleSetType: 'OWASP'
          ruleSetVersion: '3.2'
        }
      ]
    }
  }
}

// ----------------------------------------------------------------------------
// Application Gateway v2 con WAF_v2 (Sección 12.1: recomendado sobre Basic/v1)
// ----------------------------------------------------------------------------
resource appGateway 'Microsoft.Network/applicationGateways@2023-09-01' = {
  name: '${namePrefix}-appgw'
  location: location
  tags: tags
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: {
      '${managedIdentityId}': {}
    }
  }
  properties: {
    sku: {
      name: 'WAF_v2'
      tier: 'WAF_v2'
    }
    autoscaleConfiguration: {
      minCapacity: autoscaleMinCapacity
      maxCapacity: autoscaleMaxCapacity
    }
    firewallPolicy: {
      id: wafPolicy.id
    }
    gatewayIPConfigurations: [
      {
        name: 'gatewayIpConfig'
        properties: {
          subnet: {
            id: subnetId
          }
        }
      }
    ]
    sslCertificates: [
      {
        name: 'appSslCert'
        properties: {
          keyVaultSecretId: sslCertKeyVaultSecretId
        }
      }
    ]
    frontendIPConfigurations: [
      {
        name: 'frontendIpPublic'
        properties: {
          publicIPAddress: {
            id: pipAppGw.id
          }
        }
      }
    ]
    frontendPorts: [
      {
        name: 'port443'
        properties: {
          port: 443
        }
      }
    ]
    backendAddressPools: [
      {
        name: 'appServerPool'
        properties: {
          backendAddresses: [
            {
              fqdn: backendFqdnOrIp
            }
          ]
        }
      }
    ]
    backendHttpSettingsCollection: [
      {
        name: 'appServerHttpSettings'
        properties: {
          port: backendPort
          protocol: 'Https'
          cookieBasedAffinity: 'Disabled'
          pickHostNameFromBackendAddress: true
          requestTimeout: 30
          probe: {
            id: resourceId('Microsoft.Network/applicationGateways/probes', '${namePrefix}-appgw', 'appHealthProbe')
          }
        }
      }
    ]
    probes: [
      {
        name: 'appHealthProbe'
        properties: {
          protocol: 'Https'
          path: '/'
          interval: 30
          timeout: 30
          unhealthyThreshold: 3
          pickHostNameFromBackendHttpSettings: true
        }
      }
    ]
    httpListeners: [
      {
        name: 'httpsListener'
        properties: {
          frontendIPConfiguration: {
            id: resourceId('Microsoft.Network/applicationGateways/frontendIPConfigurations', '${namePrefix}-appgw', 'frontendIpPublic')
          }
          frontendPort: {
            id: resourceId('Microsoft.Network/applicationGateways/frontendPorts', '${namePrefix}-appgw', 'port443')
          }
          protocol: 'Https'
          sslCertificate: {
            id: resourceId('Microsoft.Network/applicationGateways/sslCertificates', '${namePrefix}-appgw', 'appSslCert')
          }
        }
      }
    ]
    requestRoutingRules: [
      {
        name: 'httpsRoutingRule'
        properties: {
          ruleType: 'Basic'
          priority: 100
          httpListener: {
            id: resourceId('Microsoft.Network/applicationGateways/httpListeners', '${namePrefix}-appgw', 'httpsListener')
          }
          backendAddressPool: {
            id: resourceId('Microsoft.Network/applicationGateways/backendAddressPools', '${namePrefix}-appgw', 'appServerPool')
          }
          backendHttpSettings: {
            id: resourceId('Microsoft.Network/applicationGateways/backendHttpSettingsCollection', '${namePrefix}-appgw', 'appServerHttpSettings')
          }
        }
      }
    ]
  }
}

output appGatewayId string = appGateway.id
output publicIpAddress string = pipAppGw.properties.ipAddress
output publicIpFqdn string = pipAppGw.properties.dnsSettings.fqdn
