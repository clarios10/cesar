// ============================================================================
// modules/vmApp.bicep
// VM Servidor de Aplicación — Sección 7.1 de la propuesta
// SKU: Standard DC16ds_v3 (16 vCPU / 128 GB RAM) — según hoja de costos
// (0_1-Info_Infra_01.csv): "1 DC16ds v3 (16 Cores, 128 GB RAM) x 730 Horas
// (Pay as you go), Windows (Licencia incluida)"
// Windows Server 2025, disco OS 512GB + disco Aplicativo 1TB + disco Logs 512GB
// (Premium SSD). MS Office Profesional y Terminal Services se instalan
// post-aprovisionamiento (Custom Script Extension / manual, fuera de este módulo).
// ============================================================================

@description('Prefijo de nombre para los recursos')
param namePrefix string

@description('Región de despliegue')
param location string

@description('Id de la subred de Aplicación (VLAN App)')
param subnetId string

@description('Tamaño de VM — por defecto Standard_DC16ds_v3 (16 vCPU/128GB), según hoja de costos de infraestructura')
param vmSize string = 'Standard_DC16ds_v3'

@description('Nombre de usuario administrador local')
param adminUsername string

@description('Contraseña del administrador local (usar Key Vault reference en el parámetro, nunca texto plano en el repositorio)')
@secure()
param adminPassword string

@description('Habilita RDS/Terminal Services vía extensión post-deploy (requiere script/DSC adicional del equipo de implementación)')
param enableTerminalServicesNote bool = true

@description('Tags a aplicar')
param tags object = {}

// ----------------------------------------------------------------------------
// NIC — sin IP pública (solo alcanzable desde el Application Gateway, Sección 4.2)
// ----------------------------------------------------------------------------
resource nicApp 'Microsoft.Network/networkInterfaces@2023-09-01' = {
  name: '${namePrefix}-app-nic'
  location: location
  tags: tags
  properties: {
    ipConfigurations: [
      {
        name: 'ipconfig1'
        properties: {
          privateIPAllocationMethod: 'Dynamic'
          subnet: {
            id: subnetId
          }
        }
      }
    ]
  }
}

// ----------------------------------------------------------------------------
// VM Servidor de Aplicación
// Discos: OS 512GB, Aplicativo 1TB (LUN 0), Logs 512GB (LUN 1) — Premium SSD (Sección 7.1)
// ----------------------------------------------------------------------------
resource vmApp 'Microsoft.Compute/virtualMachines@2023-09-01' = {
  name: '${namePrefix}-vm-app'
  location: location
  tags: union(tags, {
    Rol: 'ServidorAplicacion'
    RequiereConfigPost: enableTerminalServicesNote ? 'MSOffice+TerminalServices' : 'N/A'
  })
  properties: {
    hardwareProfile: {
      vmSize: vmSize
    }
    osProfile: {
      computerName: 'vm-app-01'
      adminUsername: adminUsername
      adminPassword: adminPassword
      windowsConfiguration: {
        enableAutomaticUpdates: true
        patchSettings: {
          patchMode: 'AutomaticByOS'
        }
      }
    }
    storageProfile: {
      imageReference: {
        publisher: 'MicrosoftWindowsServer'
        offer: 'WindowsServer'
        sku: '2025-datacenter-azure-edition'
        version: 'latest'
      }
      osDisk: {
        name: '${namePrefix}-app-osdisk'
        createOption: 'FromImage'
        diskSizeGB: 512
        managedDisk: {
          storageAccountType: 'Premium_LRS'
        }
      }
      dataDisks: [
        {
          name: '${namePrefix}-app-datadisk-app'
          lun: 0
          createOption: 'Empty'
          diskSizeGB: 1024
          managedDisk: {
            storageAccountType: 'Premium_LRS'
          }
        }
        {
          name: '${namePrefix}-app-datadisk-logs'
          lun: 1
          createOption: 'Empty'
          diskSizeGB: 512
          managedDisk: {
            storageAccountType: 'Premium_LRS'
          }
        }
      ]
    }
    networkProfile: {
      networkInterfaces: [
        {
          id: nicApp.id
        }
      ]
    }
  }
}

// Extensión de diagnóstico/monitoreo básico (Azure Monitor Agent)
resource amaApp 'Microsoft.Compute/virtualMachines/extensions@2023-09-01' = {
  parent: vmApp
  name: 'AzureMonitorWindowsAgent'
  location: location
  properties: {
    publisher: 'Microsoft.Azure.Monitor'
    type: 'AzureMonitorWindowsAgent'
    typeHandlerVersion: '1.0'
    autoUpgradeMinorVersion: true
  }
}

output vmId string = vmApp.id
output vmName string = vmApp.name
output nicId string = nicApp.id
output privateIp string = nicApp.properties.ipConfigurations[0].properties.privateIPAddress
