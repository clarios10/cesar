// ============================================================================
// modules/network.bicep
// VNet + subredes + NSGs, conforme a la Sección 4 y 7.3 de la propuesta
// (Subred Perimetral/DMZ, Aplicación, Base de Datos, Administración)
// ============================================================================

@description('Prefijo de nombre para los recursos (ej. contoso-app)')
param namePrefix string

@description('Región de despliegue')
param location string

@description('Espacio de direcciones de la VNet')
param vnetAddressPrefix string = '10.10.0.0/16'

@description('Prefijo de la subred del Application Gateway (DMZ)')
param snetAppGwPrefix string = '10.10.1.0/24'

@description('Prefijo de GatewaySubnet (VPN Gateway) — nombre reservado por Azure')
param snetGatewayPrefix string = '10.10.2.0/27'

@description('Prefijo de AzureBastionSubnet — nombre reservado por Azure, mínimo /26')
param snetBastionPrefix string = '10.10.3.0/26'

@description('Prefijo de la subred de Aplicación (VLAN App)')
param snetAppPrefix string = '10.10.10.0/24'

@description('Prefijo de la subred de Base de Datos (VLAN BD aislada)')
param snetDbPrefix string = '10.10.20.0/24'

@description('Prefijo de la subred de Administración/Monitoreo/Backups (VLAN Mgmt)')
param snetMgmtPrefix string = '10.10.30.0/24'

@description('Desplegar GatewaySubnet para VPN Gateway')
param deployVpnGateway bool = true

@description('Desplegar AzureBastionSubnet')
param deployBastion bool = true

@description('Tags a aplicar')
param tags object = {}

// ----------------------------------------------------------------------------
// NSG — Subred de Aplicación
// Regla: solo permite 443 entrante desde la subred del Application Gateway
// (Sección 7.3 de la propuesta: Origen AppGW -> VM Aplicación, TCP 443/80)
// ----------------------------------------------------------------------------
resource nsgApp 'Microsoft.Network/networkSecurityGroups@2023-09-01' = {
  name: '${namePrefix}-nsg-app'
  location: location
  tags: tags
  properties: {
    securityRules: [
      {
        name: 'Allow-HTTPS-From-AppGW'
        properties: {
          priority: 100
          direction: 'Inbound'
          access: 'Allow'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRanges: [
            '443'
            '80'
          ]
          sourceAddressPrefix: snetAppGwPrefix
          destinationAddressPrefix: '*'
        }
      }
      {
        name: 'Allow-Bastion-RDP'
        properties: {
          priority: 110
          direction: 'Inbound'
          access: 'Allow'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '3389'
          sourceAddressPrefix: snetBastionPrefix
          destinationAddressPrefix: '*'
        }
      }
      {
        name: 'Deny-Internet-Inbound'
        properties: {
          priority: 4096
          direction: 'Inbound'
          access: 'Deny'
          protocol: '*'
          sourcePortRange: '*'
          destinationPortRange: '*'
          sourceAddressPrefix: 'Internet'
          destinationAddressPrefix: '*'
        }
      }
      {
        name: 'Allow-SQL-Outbound-To-DB'
        properties: {
          priority: 100
          direction: 'Outbound'
          access: 'Allow'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '1433'
          sourceAddressPrefix: '*'
          destinationAddressPrefix: snetDbPrefix
        }
      }
    ]
  }
}

// ----------------------------------------------------------------------------
// NSG — Subred de Base de Datos (aislada)
// Regla: solo permite 1433 entrante desde la subred de Aplicación
// ----------------------------------------------------------------------------
resource nsgDb 'Microsoft.Network/networkSecurityGroups@2023-09-01' = {
  name: '${namePrefix}-nsg-db'
  location: location
  tags: tags
  properties: {
    securityRules: [
      {
        name: 'Allow-SQL-From-App'
        properties: {
          priority: 100
          direction: 'Inbound'
          access: 'Allow'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '1433'
          sourceAddressPrefix: snetAppPrefix
          destinationAddressPrefix: '*'
        }
      }
      {
        name: 'Allow-Bastion-RDP'
        properties: {
          priority: 110
          direction: 'Inbound'
          access: 'Allow'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '3389'
          sourceAddressPrefix: snetBastionPrefix
          destinationAddressPrefix: '*'
        }
      }
      {
        name: 'Deny-All-Inbound'
        properties: {
          priority: 4096
          direction: 'Inbound'
          access: 'Deny'
          protocol: '*'
          sourcePortRange: '*'
          destinationPortRange: '*'
          sourceAddressPrefix: '*'
          destinationAddressPrefix: '*'
        }
      }
    ]
  }
}

// ----------------------------------------------------------------------------
// NSG — Subred de Administración / Monitoreo / Backups
// ----------------------------------------------------------------------------
resource nsgMgmt 'Microsoft.Network/networkSecurityGroups@2023-09-01' = {
  name: '${namePrefix}-nsg-mgmt'
  location: location
  tags: tags
  properties: {
    securityRules: [
      {
        name: 'Allow-Bastion-RDP-SSH'
        properties: {
          priority: 100
          direction: 'Inbound'
          access: 'Allow'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRanges: [
            '3389'
            '22'
          ]
          sourceAddressPrefix: snetBastionPrefix
          destinationAddressPrefix: '*'
        }
      }
    ]
  }
}

// ----------------------------------------------------------------------------
// VNet + Subredes
// ----------------------------------------------------------------------------
resource vnet 'Microsoft.Network/virtualNetworks@2023-09-01' = {
  name: '${namePrefix}-vnet'
  location: location
  tags: tags
  properties: {
    addressSpace: {
      addressPrefixes: [
        vnetAddressPrefix
      ]
    }
    subnets: concat(
      [
        {
          name: 'snet-appgw'
          properties: {
            addressPrefix: snetAppGwPrefix
          }
        }
        {
          name: 'snet-app'
          properties: {
            addressPrefix: snetAppPrefix
            networkSecurityGroup: {
              id: nsgApp.id
            }
          }
        }
        {
          name: 'snet-db'
          properties: {
            addressPrefix: snetDbPrefix
            networkSecurityGroup: {
              id: nsgDb.id
            }
          }
        }
        {
          name: 'snet-mgmt'
          properties: {
            addressPrefix: snetMgmtPrefix
            networkSecurityGroup: {
              id: nsgMgmt.id
            }
          }
        }
      ],
      deployVpnGateway ? [
        {
          name: 'GatewaySubnet'
          properties: {
            addressPrefix: snetGatewayPrefix
          }
        }
      ] : [],
      deployBastion ? [
        {
          name: 'AzureBastionSubnet'
          properties: {
            addressPrefix: snetBastionPrefix
          }
        }
      ] : []
    )
  }
}

output vnetId string = vnet.id
output vnetName string = vnet.name
output snetAppGwId string = vnet.properties.subnets[0].id
output snetAppId string = vnet.properties.subnets[1].id
output snetDbId string = vnet.properties.subnets[2].id
output snetMgmtId string = vnet.properties.subnets[3].id
output snetGatewayId string = deployVpnGateway ? filter(vnet.properties.subnets, s => s.name == 'GatewaySubnet')[0].id : ''
output snetBastionId string = deployBastion ? filter(vnet.properties.subnets, s => s.name == 'AzureBastionSubnet')[0].id : ''
