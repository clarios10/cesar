// ============================================================================
// modules/bastion.bicep
// Azure Bastion (Standard SKU) — Sección 7.3 y 12.2 de la propuesta
// Acceso administrativo RDP/SSH vía Azure Portal (HTTPS 443), sin exponer
// puertos de gestión a Internet. Alternativa/complemento a TC Plus.
// ============================================================================

@description('Prefijo de nombre para los recursos')
param namePrefix string

@description('Región de despliegue')
param location string

@description('Id de la subred AzureBastionSubnet (nombre reservado, mínimo /26)')
param bastionSubnetId string

@description('Tags a aplicar')
param tags object = {}

resource pipBastion 'Microsoft.Network/publicIPAddresses@2023-09-01' = {
  name: '${namePrefix}-pip-bastion'
  location: location
  tags: tags
  sku: {
    name: 'Standard'
  }
  properties: {
    publicIPAllocationMethod: 'Static'
  }
}

resource bastion 'Microsoft.Network/bastionHosts@2023-09-01' = {
  name: '${namePrefix}-bastion'
  location: location
  tags: tags
  sku: {
    name: 'Standard'
  }
  properties: {
    enableTunneling: true
    ipConfigurations: [
      {
        name: 'bastionIpConfig'
        properties: {
          subnet: {
            id: bastionSubnetId
          }
          publicIPAddress: {
            id: pipBastion.id
          }
        }
      }
    ]
  }
}

output bastionId string = bastion.id
