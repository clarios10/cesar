// ============================================================================
// modules/monitoring.bicep
// Azure Monitor / Log Analytics — Sección 4.6 y 11 de la propuesta
// Monitoreo básico de ambas VMs + alertas de disponibilidad y consumo
// ============================================================================

@description('Prefijo de nombre para los recursos')
param namePrefix string

@description('Región de despliegue')
param location string

@description('Retención de logs en días')
param retentionInDays int = 30

@description('Ids de las VMs a monitorear (App y DB) para asociar Data Collection Rules')
param vmResourceIds array = []

@description('Email para notificación de alertas')
param alertEmail string

@description('Tags a aplicar')
param tags object = {}

resource logAnalytics 'Microsoft.OperationalInsights/workspaces@2023-09-01' = {
  name: '${namePrefix}-law'
  location: location
  tags: tags
  properties: {
    sku: {
      name: 'PerGB2018'
    }
    retentionInDays: retentionInDays
  }
}

resource actionGroup 'Microsoft.Insights/actionGroups@2023-01-01' = {
  name: '${namePrefix}-ag-infra'
  location: 'global'
  tags: tags
  properties: {
    groupShortName: 'infraAlert'
    enabled: true
    emailReceivers: [
      {
        name: 'AdminTI'
        emailAddress: alertEmail
        useCommonAlertSchema: true
      }
    ]
  }
}

// Alerta de disponibilidad (VM apagada/no responde) por cada VM provista
resource vmAvailabilityAlerts 'Microsoft.Insights/metricAlerts@2018-03-01' = [for (vmId, i) in vmResourceIds: {
  name: '${namePrefix}-alert-vm-availability-${i}'
  location: 'global'
  tags: tags
  properties: {
    severity: 1
    enabled: true
    scopes: [
      vmId
    ]
    evaluationFrequency: 'PT5M'
    windowSize: 'PT15M'
    criteria: {
      'odata.type': 'Microsoft.Azure.Monitor.SingleResourceMultipleMetricCriteria'
      allOf: [
        {
          name: 'VmAvailability'
          metricName: 'VmAvailabilityMetric'
          operator: 'LessThan'
          threshold: 1
          timeAggregation: 'Average'
          criterionType: 'StaticThresholdCriterion'
        }
      ]
    }
    actions: [
      {
        actionGroupId: actionGroup.id
      }
    ]
  }
}]

// Alerta de consumo elevado de CPU (> 85% sostenido)
resource vmCpuAlerts 'Microsoft.Insights/metricAlerts@2018-03-01' = [for (vmId, i) in vmResourceIds: {
  name: '${namePrefix}-alert-vm-cpu-${i}'
  location: 'global'
  tags: tags
  properties: {
    severity: 2
    enabled: true
    scopes: [
      vmId
    ]
    evaluationFrequency: 'PT5M'
    windowSize: 'PT15M'
    criteria: {
      'odata.type': 'Microsoft.Azure.Monitor.SingleResourceMultipleMetricCriteria'
      allOf: [
        {
          name: 'HighCPU'
          metricName: 'Percentage CPU'
          operator: 'GreaterThan'
          threshold: 85
          timeAggregation: 'Average'
          criterionType: 'StaticThresholdCriterion'
        }
      ]
    }
    actions: [
      {
        actionGroupId: actionGroup.id
      }
    ]
  }
}]

output logAnalyticsWorkspaceId string = logAnalytics.id
output actionGroupId string = actionGroup.id
