// ============================================================================
// modules/backup.bicep
// Azure Backup / Recovery Services Vault — Sección 4.6 y 11 de la propuesta
// Respaldo de las VMs de Aplicación y Base de Datos (política diaria +
// retención semanal/mensual)
// ============================================================================

@description('Prefijo de nombre para los recursos')
param namePrefix string

@description('Región de despliegue')
param location string

@description('Redundancia del Vault: LRS o GRS (Sección 11: "GRS o LRS según criticidad")')
@allowed([
  'LocallyRedundant'
  'GeoRedundant'
])
param vaultStorageRedundancy string = 'GeoRedundant'

@description('Hora de inicio del backup diario (UTC, formato ISO 8601)')
param backupTimeUtc string = '2025-01-01T05:00:00Z'

@description('Tags a aplicar')
param tags object = {}

@description('Lista de VMs a proteger: [{ vmId: string, vmName: string }] (App y DB)')
param vmsToProtect array = []

resource vault 'Microsoft.RecoveryServices/vaults@2023-06-01' = {
  name: '${namePrefix}-rsv'
  location: location
  tags: tags
  sku: {
    name: 'RS0'
    tier: 'Standard'
  }
  properties: {}
}

resource vaultConfig 'Microsoft.RecoveryServices/vaults/backupconfig@2023-06-01' = {
  parent: vault
  name: 'vaultconfig'
  properties: {
    enhancedSecurityState: 'Enabled'
    softDeleteFeatureState: 'Enabled'
  }
}

resource vaultStorageConfig 'Microsoft.RecoveryServices/vaults/backupstorageconfig@2023-06-01' = {
  parent: vault
  name: 'vaultstorageconfig'
  properties: {
    storageModelType: vaultStorageRedundancy
    crossRegionRestoreFlag: false
  }
}

// Política: backup diario, retención 30 días diaria + 12 semanas semanal + 12 meses mensual
resource backupPolicy 'Microsoft.RecoveryServices/vaults/backupPolicies@2023-06-01' = {
  parent: vault
  name: '${namePrefix}-backup-policy'
  properties: {
    backupManagementType: 'AzureIaasVM'
    schedulePolicy: {
      schedulePolicyType: 'SimpleSchedulePolicy'
      scheduleRunFrequency: 'Daily'
      scheduleRunTimes: [
        backupTimeUtc
      ]
    }
    retentionPolicy: {
      retentionPolicyType: 'LongTermRetentionPolicy'
      dailySchedule: {
        retentionTimes: [
          backupTimeUtc
        ]
        retentionDuration: {
          count: 30
          durationType: 'Days'
        }
      }
      weeklySchedule: {
        daysOfTheWeek: [
          'Sunday'
        ]
        retentionTimes: [
          backupTimeUtc
        ]
        retentionDuration: {
          count: 12
          durationType: 'Weeks'
        }
      }
      monthlySchedule: {
        retentionScheduleFormatType: 'Weekly'
        retentionScheduleWeekly: {
          daysOfTheWeek: [
            'Sunday'
          ]
          weeksOfTheMonth: [
            'First'
          ]
        }
        retentionTimes: [
          backupTimeUtc
        ]
        retentionDuration: {
          count: 12
          durationType: 'Months'
        }
      }
    }
    timeZone: 'UTC'
  }
}

output vaultId string = vault.id
output backupPolicyId string = backupPolicy.id

// ----------------------------------------------------------------------------
// Registro de las VMs como elementos protegidos (App y DB) en el Vault
// Naming convention requerida por el proveedor Azure Backup para IaaS VMs
// ----------------------------------------------------------------------------
resource fabric 'Microsoft.RecoveryServices/vaults/backupFabrics@2023-06-01' = {
  parent: vault
  name: 'Azure'
}

resource protectionContainers 'Microsoft.RecoveryServices/vaults/backupFabrics/protectionContainers@2023-06-01' = [for vm in vmsToProtect: {
  parent: fabric
  name: 'iaasvmcontainer;iaasvmcontainer;${resourceGroup().name};${vm.vmName}'
  properties: {
    backupManagementType: 'AzureIaasVM'
    containerType: 'Microsoft.Compute/virtualMachines'
    sourceResourceId: vm.vmId
    friendlyName: vm.vmName
  }
}]

resource protectedItems 'Microsoft.RecoveryServices/vaults/backupFabrics/protectionContainers/protectedItems@2023-06-01' = [for (vm, i) in vmsToProtect: {
  parent: protectionContainers[i]
  name: 'vm;iaasvmcontainer;${resourceGroup().name};${vm.vmName}'
  properties: {
    protectedItemType: 'Microsoft.Compute/virtualMachines'
    policyId: backupPolicy.id
    sourceResourceId: vm.vmId
  }
}]
// NOTA: los warnings BCP081/BCP037/BCP073 en este archivo son limitaciones
// conocidas de los tipos Bicep incluidos para Microsoft.RecoveryServices
// (definiciones de tipo incompletas en el proveedor). "sourceResourceId" es
// la propiedad correcta según la documentación de la API REST de Azure
// Backup y el template no falla en tiempo de despliegue por este motivo.
