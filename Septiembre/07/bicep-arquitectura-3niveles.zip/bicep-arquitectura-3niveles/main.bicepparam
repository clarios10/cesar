using 'main.bicep'

// ============================================================================
// Parámetros de ejemplo — AJUSTAR antes de desplegar en un ambiente real.
// Los valores marcados como secretos NO deben quedar en texto plano en el
// repositorio: usar --parameters adminPassword=$(az keyvault secret show ...)
// o referencias getSecret() de Key Vault en este mismo archivo.
// ============================================================================

param namePrefix = 'contoso'
param location = 'eastus2'

param adminUsername = 'azadmin'
// Reemplazar por una referencia segura antes de desplegar, por ejemplo:
// param adminPassword = az.getSecret('<subscriptionId>', '<rgName>', '<kvName>', 'vmAdminPassword')
param adminPassword = 'REEMPLAZAR-ANTES-DE-DESPLEGAR'

// Certificado TLS del listener del Application Gateway (debe existir en Key Vault)
param sslCertKeyVaultSecretId = 'https://kv-contoso-app.vault.azure.net/secrets/app-tls-cert'
param managedIdentityId = '/subscriptions/<subId>/resourceGroups/rg-contoso-app-prod/providers/Microsoft.ManagedIdentity/userAssignedIdentities/id-appgw-kv-reader'

// Sección 12.3 de la propuesta: componentes opcionales/recomendados
param deployVpnGateway = true
param deployBastion = true

// Sección 11: modalidad de licenciamiento SQL Server (PAYG o AHUB)
param sqlLicenseType = 'AHUB'

// Sección 7.3: 1 túnel S2S por sucursal (ejemplo con 2 sucursales)
param branchGatewayIps = [
  '203.0.113.10'
  '203.0.113.20'
]
param branchAddressPrefixes = [
  '192.168.1.0/24'
  '192.168.2.0/24'
]
param vpnSharedKey = 'REEMPLAZAR-ANTES-DE-DESPLEGAR'

param alertEmail = 'ti@contoso.com'

param tags = {
  Proyecto: 'Solucion-Web-3Niveles'
  Ambiente: 'Produccion'
  Propuesta: 'Propuesta Arquitectura Azure 3Niveles'
  CentroCosto: 'TI-Infraestructura'
}
