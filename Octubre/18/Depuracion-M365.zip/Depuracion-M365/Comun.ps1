<#
.SYNOPSIS
  Funciones compartidas por los scripts de depuracion del tenant M365 (Supra Terra).
  No se ejecuta solo: cada script lo carga con  . "$PSScriptRoot\Comun.ps1"

.NOTES
  Requiere PowerShell 7.x y los modulos:
    Microsoft.Graph (v2), Microsoft.Graph.Beta.Identity.DirectoryManagement, ExchangeOnlineManagement
  Etiqueta usada en todos los objetos:  M365DEP|<Fase>|<yyyy-MM-dd>|<Motivos>
#>

$ErrorActionPreference = 'Stop'

$Script:PrefijoEtiqueta = 'M365DEP'
$Script:Hoy            = Get-Date -Format 'yyyy-MM-dd'
$Script:Marca          = Get-Date -Format 'yyyyMMdd_HHmmss'
$Script:RutaSalida     = Join-Path $PSScriptRoot 'salida'
$Script:RutaRespaldo   = Join-Path $PSScriptRoot 'respaldo'
$Script:Codificacion   = if ($PSVersionTable.PSVersion.Major -ge 6) { 'utf8BOM' } else { 'UTF8' }
$Script:ArchivoLog     = $null

foreach ($r in @($Script:RutaSalida, $Script:RutaRespaldo)) {
    if (-not (Test-Path $r)) { New-Item -ItemType Directory -Path $r -Force | Out-Null }
}

# ---------------------------------------------------------------- Bitacora
function Start-Bitacora {
    param([Parameter(Mandatory)][string]$Nombre)
    $Script:ArchivoLog = Join-Path $Script:RutaSalida ("bitacora_{0}_{1}.csv" -f $Nombre, $Script:Marca)
    Write-Host "Bitacora: $Script:ArchivoLog" -ForegroundColor Cyan
}

function Write-Bitacora {
    param(
        [string]$Fase, [string]$Tipo, [string]$Id, [string]$Nombre,
        [string]$Accion, [ValidateSet('OK','SIMULADO','OMITIDO','ERROR','INFO')][string]$Resultado,
        [string]$Detalle = ''
    )
    $fila = [pscustomobject]@{
        FechaHora = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'); Fase = $Fase; Tipo = $Tipo; Id = $Id
        Nombre = $Nombre; Accion = $Accion; Resultado = $Resultado; Detalle = $Detalle
        Operador = (Get-MgContext).Account
    }
    if ($Script:ArchivoLog) { $fila | Export-Csv -Path $Script:ArchivoLog -Append -NoTypeInformation -Encoding $Script:Codificacion }
    $color = switch ($Resultado) { 'OK' {'Green'} 'SIMULADO' {'Yellow'} 'ERROR' {'Red'} default {'Gray'} }
    Write-Host ("[{0}] {1} {2} -> {3} {4}" -f $Resultado, $Tipo, $Nombre, $Accion, $Detalle) -ForegroundColor $color
}

# ---------------------------------------------------------------- Conexion
$Script:ScopesLectura = @(
    'User.Read.All','Group.Read.All','GroupMember.Read.All','Device.Read.All','AuditLog.Read.All',
    'Directory.Read.All','Organization.Read.All','RoleManagement.Read.Directory','Reports.Read.All',
    'BitlockerKey.ReadBasic.All'
)
$Script:ScopesEscritura = @(
    'User.ReadWrite.All','Group.ReadWrite.All','GroupMember.ReadWrite.All','Device.ReadWrite.All',
    'Directory.ReadWrite.All','Directory.AccessAsUser.All','User.RevokeSessions.All',
    'LicenseAssignment.ReadWrite.All','AuditLog.Read.All','BitlockerKey.Read.All',
    'DeviceManagementManagedDevices.ReadWrite.All'
)

function Connect-Servicios {
    param([switch]$Escritura, [switch]$SinExchange, [string[]]$ScopesExtra = @())
    $scopes = if ($Escritura) { $Script:ScopesEscritura } else { $Script:ScopesLectura }
    $scopes = @($scopes + $ScopesExtra | Select-Object -Unique)
    Connect-MgGraph -Scopes $scopes -NoWelcome
    Write-Host ("Graph conectado como {0} (tenant {1})" -f (Get-MgContext).Account, (Get-MgContext).TenantId) -ForegroundColor Cyan
    if (-not $SinExchange) {
        if (-not (Get-ConnectionInformation -ErrorAction SilentlyContinue)) {
            Connect-ExchangeOnline -ShowBanner:$false
        }
        Write-Host "Exchange Online conectado." -ForegroundColor Cyan
    }
}

function Assert-TenantNube {
    # Si el tenant aun tiene la marca de sincronizacion, los objetos antes sincronizados son de solo lectura.
    $org = Get-MgOrganization -Property Id,DisplayName,OnPremisesSyncEnabled,OnPremisesLastSyncDateTime
    if ($org.OnPremisesSyncEnabled -eq $true) {
        throw "El tenant sigue con OnPremisesSyncEnabled = True (ultima sincronizacion: $($org.OnPremisesLastSyncDateTime)). Ejecuta primero 00-Prerrequisitos.ps1 -DesactivarSincronizacion."
    }
}

# ---------------------------------------------------------------- Utilidades
function Get-Ultimo {
    param([object[]]$Fechas)
    $v = @($Fechas | Where-Object { $_ } | ForEach-Object { [datetime]$_ } | Sort-Object -Descending)
    if ($v.Count -gt 0) { return $v[0] } else { return $null }
}

function Import-Aprobados {
    # Devuelve solo las filas con Aprobado = SI y la accion indicada.
    param([Parameter(Mandatory)][string]$Archivo, [string[]]$Accion = @('Baja'))
    if (-not (Test-Path $Archivo)) { throw "No existe el archivo $Archivo" }
    $filas = @(Import-Csv -Path $Archivo -Encoding $Script:Codificacion |
        Where-Object { ($_.Aprobado -as [string]).Trim().ToUpper() -eq 'SI' -and $Accion -contains $_.AccionPropuesta })
    Write-Host ("{0}: {1} filas aprobadas para {2}" -f (Split-Path $Archivo -Leaf), $filas.Count, ($Accion -join ',')) -ForegroundColor Cyan
    return $filas
}

function Get-TipoGrupo {
    param($Grupo)
    if ($Grupo.GroupTypes -contains 'Unified') { return 'M365' }
    if ($Grupo.MailEnabled -and $Grupo.SecurityEnabled) { return 'SeguridadCorreo' }
    if ($Grupo.MailEnabled) { return 'Distribucion' }
    return 'Seguridad'
}

# ---------------------------------------------------------------- Etiquetas
# Usuarios     -> extensionAttribute15 (Graph)
# Dispositivos -> extensionAttributes.extensionAttribute15 (Graph)
# Grupos M365 y de seguridad -> prefijo [M365DEP|...] en la descripcion (Graph)
# Listas de distribucion y seguridad con correo -> CustomAttribute15 (Exchange Online)

$Script:RegexEtiquetaDescripcion = '^\[M365DEP\|[^\]]*\]\s*'

function New-ValorEtiqueta {
    param([string]$Fase, [string]$Motivos)
    $v = '{0}|{1}|{2}|{3}' -f $Script:PrefijoEtiqueta, $Fase, $Script:Hoy, $Motivos
    if ($v.Length -gt 250) { $v = $v.Substring(0, 250) }
    return $v
}

function Get-Etiqueta {
    param([Parameter(Mandatory)][ValidateSet('Usuario','Invitado','Grupo','Dispositivo')][string]$Tipo,
          [Parameter(Mandatory)][string]$Id)
    switch ($Tipo) {
        { $_ -in 'Usuario','Invitado' } {
            $u = Get-MgUser -UserId $Id -Property OnPremisesExtensionAttributes
            return $u.OnPremisesExtensionAttributes.ExtensionAttribute15
        }
        'Dispositivo' {
            $d = Get-MgDevice -DeviceId $Id -Property ExtensionAttributes
            return $d.ExtensionAttributes.ExtensionAttribute15
        }
        'Grupo' {
            $g = Get-MgGroup -GroupId $Id -Property Id,GroupTypes,MailEnabled,SecurityEnabled,Description,Mail
            $t = Get-TipoGrupo $g
            if ($t -in 'Distribucion','SeguridadCorreo') {
                return (Get-DistributionGroup -Identity $Id).CustomAttribute15
            }
            if ($g.Description -and $g.Description -match '^\[(M365DEP\|[^\]]*)\]') { return $Matches[1] }
            return $null
        }
    }
}

function Set-Etiqueta {
    param([Parameter(Mandatory)][ValidateSet('Usuario','Invitado','Grupo','Dispositivo')][string]$Tipo,
          [Parameter(Mandatory)][string]$Id,
          [AllowNull()][AllowEmptyString()][string]$Valor)   # $null o '' = quitar etiqueta
    $limpiar = [string]::IsNullOrEmpty($Valor)
    switch ($Tipo) {
        { $_ -in 'Usuario','Invitado' } {
            $body = @{ onPremisesExtensionAttributes = @{ extensionAttribute15 = $(if ($limpiar) { $null } else { $Valor }) } }
            Update-MgUser -UserId $Id -BodyParameter $body
        }
        'Dispositivo' {
            $body = @{ extensionAttributes = @{ extensionAttribute15 = $(if ($limpiar) { $null } else { $Valor }) } }
            Update-MgDevice -DeviceId $Id -BodyParameter $body
        }
        'Grupo' {
            $g = Get-MgGroup -GroupId $Id -Property Id,GroupTypes,MailEnabled,SecurityEnabled,Description,Mail
            $t = Get-TipoGrupo $g
            if ($t -in 'Distribucion','SeguridadCorreo') {
                Set-DistributionGroup -Identity $Id -CustomAttribute15 $(if ($limpiar) { $null } else { $Valor }) -BypassSecurityGroupManagerCheck
            }
            else {
                $base = if ($g.Description) { $g.Description -replace $Script:RegexEtiquetaDescripcion, '' } else { '' }
                $nueva = if ($limpiar) { $base } else { ("[{0}] {1}" -f $Valor, $base).Trim() }
                if ([string]::IsNullOrWhiteSpace($nueva)) { $nueva = $null }
                Update-MgGroup -GroupId $Id -BodyParameter @{ description = $nueva }
            }
        }
    }
}

function Test-EtiquetaFase {
    # Devuelve un objeto con Ok, Fase y Fecha de la etiqueta actual.
    param([string]$Etiqueta, [Parameter(Mandatory)][string]$FaseEsperada, [int]$DiasMinimos = 0)
    $r = [pscustomobject]@{ Ok = $false; Fase = $null; Fecha = $null; Motivo = '' }
    if ([string]::IsNullOrEmpty($Etiqueta) -or -not $Etiqueta.StartsWith("$($Script:PrefijoEtiqueta)|")) {
        $r.Motivo = 'Sin etiqueta M365DEP'; return $r
    }
    $p = $Etiqueta.Split('|')
    $r.Fase = $p[1]
    $r.Fecha = [datetime]::ParseExact($p[2], 'yyyy-MM-dd', $null)
    if ($r.Fase -ne $FaseEsperada) { $r.Motivo = "Etiqueta en fase $($r.Fase), se esperaba $FaseEsperada"; return $r }
    $dias = ((Get-Date) - $r.Fecha).Days
    if ($dias -lt $DiasMinimos) { $r.Motivo = "Solo lleva $dias dias en $FaseEsperada (minimo $DiasMinimos)"; return $r }
    $r.Ok = $true
    return $r
}
