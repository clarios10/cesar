<#
.SYNOPSIS
  Fase 0 - Prerrequisitos. Verifica que el tenant ya este realmente en nube y lista los restos de la sincronizacion.

.DESCRIPTION
  1. Instala/valida modulos.
  2. Revisa OnPremisesSyncEnabled del tenant. Si sigue en True, los objetos antes sincronizados
     NO se pueden editar, deshabilitar ni eliminar desde la nube.
  3. Cuenta usuarios/grupos/dispositivos que aun se marcan como sincronizados.
  4. Lista restos: cuenta Sync_*, rol Directory Synchronization Accounts, administradores globales.

.EXAMPLE
  .\00-Prerrequisitos.ps1                              # solo diagnostico
  .\00-Prerrequisitos.ps1 -DesactivarSincronizacion    # simula la desactivacion
  .\00-Prerrequisitos.ps1 -DesactivarSincronizacion -Ejecutar   # desactiva (puede tardar hasta 72 h)
#>
[CmdletBinding()]
param(
    [switch]$InstalarModulos,
    [switch]$DesactivarSincronizacion,
    [switch]$Ejecutar
)

if ($InstalarModulos) {
    foreach ($m in 'Microsoft.Graph','Microsoft.Graph.Beta.Identity.DirectoryManagement','ExchangeOnlineManagement') {
        if (-not (Get-Module -ListAvailable -Name $m)) {
            Write-Host "Instalando $m ..." -ForegroundColor Cyan
            Install-Module $m -Scope CurrentUser -Force -AllowClobber
        }
    }
}

. "$PSScriptRoot\Comun.ps1"
Start-Bitacora -Nombre 'F0_Prerrequisitos'

$extra = @()
if ($DesactivarSincronizacion) { $extra = @('Organization.ReadWrite.All') }
Connect-Servicios -SinExchange -ScopesExtra $extra

# --- 1. Marca de sincronizacion del tenant
$org = Get-MgOrganization -Property Id,DisplayName,OnPremisesSyncEnabled,OnPremisesLastSyncDateTime,OnPremisesLastPasswordSyncDateTime
Write-Host "`n== Tenant: $($org.DisplayName)" -ForegroundColor White
Write-Host ("OnPremisesSyncEnabled        : {0}" -f $org.OnPremisesSyncEnabled)
Write-Host ("Ultima sincronizacion        : {0}" -f $org.OnPremisesLastSyncDateTime)
Write-Host ("Ultima sinc. de contrasenas  : {0}" -f $org.OnPremisesLastPasswordSyncDateTime)
Write-Bitacora -Fase F0 -Tipo Tenant -Id $org.Id -Nombre $org.DisplayName -Accion 'Revisar sincronizacion' -Resultado INFO -Detalle "OnPremisesSyncEnabled=$($org.OnPremisesSyncEnabled)"

if ($org.OnPremisesSyncEnabled -eq $true) {
    Write-Warning "El tenant AUN tiene la sincronizacion habilitada. Mientras siga asi, los objetos sincronizados son de solo lectura."
    if ($DesactivarSincronizacion) {
        if ($Ejecutar) {
            Import-Module Microsoft.Graph.Beta.Identity.DirectoryManagement
            Update-MgBetaOrganization -OrganizationId $org.Id -BodyParameter @{ onPremisesSyncEnabled = $false }
            Write-Bitacora -Fase F0 -Tipo Tenant -Id $org.Id -Nombre $org.DisplayName -Accion 'Desactivar sincronizacion' -Resultado OK -Detalle 'Puede tardar hasta 72 h. Volver a ejecutar este script para confirmar.'
        } else {
            Write-Bitacora -Fase F0 -Tipo Tenant -Id $org.Id -Nombre $org.DisplayName -Accion 'Desactivar sincronizacion' -Resultado SIMULADO -Detalle 'Agregar -Ejecutar para aplicar'
        }
    }
}
elseif ($null -eq $org.OnPremisesSyncEnabled -or $org.OnPremisesSyncEnabled -eq $false) {
    Write-Host "OK: el tenant ya no tiene sincronizacion habilitada." -ForegroundColor Green
}

# --- 2. Objetos que aun se marcan como sincronizados (deben ser 0 al terminar la desactivacion)
$uSync = @(Get-MgUser -All -Filter 'onPremisesSyncEnabled eq true' -ConsistencyLevel eventual -CountVariable cu -Property Id)
$gSync = @(Get-MgGroup -All -Filter 'onPremisesSyncEnabled eq true' -ConsistencyLevel eventual -CountVariable cg -Property Id)
$dSync = @(Get-MgDevice -All -Filter 'onPremisesSyncEnabled eq true' -ConsistencyLevel eventual -CountVariable cd -Property Id)
Write-Host "`n== Objetos aun marcados como sincronizados" -ForegroundColor White
Write-Host ("Usuarios: {0}  Grupos: {1}  Dispositivos: {2}" -f $uSync.Count, $gSync.Count, $dSync.Count)
Write-Bitacora -Fase F0 -Tipo Tenant -Id $org.Id -Nombre 'Objetos sincronizados' -Accion 'Conteo' -Resultado INFO -Detalle "U=$($uSync.Count) G=$($gSync.Count) D=$($dSync.Count)"

# --- 3. Restos de Entra Connect
Write-Host "`n== Restos de Entra Connect" -ForegroundColor White
$cuentasSync = @(Get-MgUser -All -Filter "startswith(userPrincipalName,'Sync_')" -Property Id,UserPrincipalName,AccountEnabled)
$cuentasSync | ForEach-Object {
    Write-Host ("Cuenta de sincronizacion: {0} (habilitada: {1})" -f $_.UserPrincipalName, $_.AccountEnabled) -ForegroundColor Yellow
    Write-Bitacora -Fase F0 -Tipo Usuario -Id $_.Id -Nombre $_.UserPrincipalName -Accion 'Resto de Entra Connect' -Resultado INFO -Detalle 'Candidata a baja (motivo U07)'
}
$rolSync = Get-MgDirectoryRole -All | Where-Object DisplayName -eq 'Directory Synchronization Accounts'
if ($rolSync) {
    $m = @(Get-MgDirectoryRoleMember -DirectoryRoleId $rolSync.Id -All)
    Write-Host ("Miembros del rol Directory Synchronization Accounts: {0}" -f $m.Count)
}

# --- 4. Administradores globales (validar cuentas de emergencia solo nube)
Write-Host "`n== Administradores globales" -ForegroundColor White
$rolGA = Get-MgDirectoryRole -All | Where-Object DisplayName -eq 'Global Administrator'
$ga = @(Get-MgDirectoryRoleMember -DirectoryRoleId $rolGA.Id -All)
$ga | ForEach-Object {
    $u = Get-MgUser -UserId $_.Id -Property UserPrincipalName,AccountEnabled,OnPremisesImmutableId -ErrorAction SilentlyContinue
    if ($u) {
        Write-Host ("{0}  habilitado={1}  antes_sincronizado={2}" -f $u.UserPrincipalName, $u.AccountEnabled, [bool]$u.OnPremisesImmutableId)
    }
}
if ($ga.Count -lt 2) { Write-Warning 'Hay menos de 2 administradores globales. Crea 2 cuentas de emergencia solo nube antes de continuar.' }

# --- 5. Papelera actual (para no confundir con lo que se borre despues)
$papU = @(Get-MgDirectoryDeletedItemAsUser -All)
$papG = @(Get-MgDirectoryDeletedItemAsGroup -All)
Write-Host ("`nEn papelera hoy -> usuarios: {0}  grupos: {1}" -f $papU.Count, $papG.Count)

Write-Host "`nSiguiente paso: 01-Identificacion.ps1" -ForegroundColor Cyan
