<#
.SYNOPSIS
  Fase 4 - Eliminar. Borra los objetos que cumplieron la cuarentena en estado deshabilitado.

.DESCRIPTION
  Solo procesa filas Aprobado = SI, AccionPropuesta = Baja, con etiqueta F3 y al menos -DiasCuarentena dias.
    Usuarios     : si ConservarBuzon = SI, el buzon se convierte a compartido, se quitan licencias directas
                   y la cuenta queda deshabilitada (no se borra). Si no, la cuenta se elimina
                   (queda 30 dias en la papelera de Entra; ver 04b-Restaurar.ps1).
    Grupos M365  : se eliminan (30 dias en papelera).
    Grupos de seguridad y listas de distribucion: se eliminan DE FORMA PERMANENTE (no hay papelera);
                   el respaldo de miembros queda en .\respaldo.
    Dispositivos : se eliminan de Entra (permanente) y, con -IncluirIntune, tambien de Intune.
                   Nunca se borran los registrados en Autopilot (motivo D03).
  Por defecto SIMULA. Con -Ejecutar pide escribir ELIMINAR para confirmar.

.EXAMPLE
  .\04-Eliminar.ps1 -ArchivoUsuarios .\salida\Candidatos_Usuarios_2026-10-20.csv
  .\04-Eliminar.ps1 -ArchivoUsuarios ... -ArchivoGrupos ... -ArchivoDispositivos ... -IncluirIntune -Ejecutar
#>
[CmdletBinding()]
param(
    [string]$ArchivoUsuarios,
    [string]$ArchivoGrupos,
    [string]$ArchivoDispositivos,
    [int]$DiasCuarentena = 30,
    [switch]$IncluirIntune,
    [switch]$Ejecutar
)

. "$PSScriptRoot\Comun.ps1"
Start-Bitacora -Nombre 'F4_Eliminar'
Connect-Servicios -Escritura
Assert-TenantNube

if ($Ejecutar) {
    $conf = Read-Host 'Esta fase elimina objetos. Escribe ELIMINAR para continuar'
    if ($conf -cne 'ELIMINAR') { throw 'Cancelado por el operador.' }
}
$res = if ($Ejecutar) { 'OK' } else { 'SIMULADO' }
$respaldo = [ordered]@{ Fecha = $Script:Hoy; Usuarios = @(); Grupos = @(); Dispositivos = @() }

function Test-ListoParaF4 {
    param($Fila, [string]$Tipo)
    $et = Get-Etiqueta -Tipo $Tipo -Id $Fila.Id
    $chk = Test-EtiquetaFase -Etiqueta $et -FaseEsperada 'F3' -DiasMinimos $DiasCuarentena
    if (-not $chk.Ok) {
        Write-Bitacora -Fase F4 -Tipo $Tipo -Id $Fila.Id -Nombre $Fila.DisplayName -Accion 'Eliminar' -Resultado OMITIDO -Detalle $chk.Motivo
    }
    return $chk.Ok
}

# ---------------------------------------------------------------- Usuarios
if ($ArchivoUsuarios) {
    foreach ($f in Import-Aprobados -Archivo $ArchivoUsuarios) {
        try {
            if (-not (Test-ListoParaF4 -Fila $f -Tipo $f.Tipo)) { continue }
            $u = Get-MgUser -UserId $f.Id -Property Id,DisplayName,UserPrincipalName,Mail,AccountEnabled,AssignedLicenses,LicenseAssignmentStates,Department,JobTitle
            if ($u.AccountEnabled) {
                Write-Bitacora -Fase F4 -Tipo $f.Tipo -Id $f.Id -Nombre $f.DisplayName -Accion 'Eliminar' -Resultado OMITIDO -Detalle 'La cuenta fue rehabilitada; no se elimina'
                continue
            }
            $licDirectas = @($u.LicenseAssignmentStates | Where-Object { -not $_.AssignedByGroup } | ForEach-Object { $_.SkuId.ToString() } | Select-Object -Unique)
            $grp = @(Get-MgUserMemberOf -UserId $f.Id -All | Where-Object { $_.AdditionalProperties['@odata.type'] -eq '#microsoft.graph.group' } | ForEach-Object { $_.Id })
            $mbx = Get-EXOMailbox -Identity $f.Id -Properties RecipientTypeDetails,LitigationHoldEnabled,InPlaceHolds -ErrorAction SilentlyContinue
            $respaldo.Usuarios += [pscustomobject]@{
                Id = $u.Id; UPN = $u.UserPrincipalName; DisplayName = $u.DisplayName; Mail = $u.Mail
                Departamento = $u.Department; Puesto = $u.JobTitle; LicenciasDirectas = $licDirectas; Grupos = $grp
                TipoBuzon = $(if ($mbx) { [string]$mbx.RecipientTypeDetails } else { '' })
            }

            $conservar = (($f.ConservarBuzon -as [string]).Trim().ToUpper() -eq 'SI')
            if ($conservar -and $mbx -and $mbx.RecipientTypeDetails -eq 'UserMailbox') {
                $st = Get-EXOMailboxStatistics -Identity $f.Id
                $gb = 0
                if ($st.TotalItemSize -and ($st.TotalItemSize.ToString() -match '\(([\d,\.]+) bytes\)')) { $gb = [double]($Matches[1] -replace '[,\.]','') / 1GB }
                if ($Ejecutar) {
                    Set-Mailbox -Identity $f.Id -Type Shared
                    if ($gb -lt 49 -and $licDirectas.Count -gt 0) {
                        Set-MgUserLicense -UserId $f.Id -AddLicenses @() -RemoveLicenses $licDirectas | Out-Null
                    }
                    Set-Etiqueta -Tipo $f.Tipo -Id $f.Id -Valor (New-ValorEtiqueta -Fase 'F4' -Motivos 'CONVERTIDO_A_COMPARTIDO')
                }
                $det = if ($gb -ge 49) { ("Buzon de {0:N1} GB: se conserva la licencia (compartido > 50 GB la requiere)" -f $gb) } else { 'Licencias directas liberadas; cuenta deshabilitada' }
                Write-Bitacora -Fase F4 -Tipo $f.Tipo -Id $f.Id -Nombre $f.DisplayName -Accion 'Convertir buzon a compartido' -Resultado $res -Detalle $det
                continue
            }
            if ($mbx -and ($mbx.LitigationHoldEnabled -or @($mbx.InPlaceHolds).Count -gt 0)) {
                $nota = 'Tiene retencion: el buzon quedara como buzon inactivo'
            } else { $nota = 'Papelera de Entra 30 dias' }
            if ($Ejecutar) { Remove-MgUser -UserId $f.Id }
            Write-Bitacora -Fase F4 -Tipo $f.Tipo -Id $f.Id -Nombre $f.DisplayName -Accion 'Eliminar cuenta' -Resultado $res -Detalle $nota
        } catch {
            Write-Bitacora -Fase F4 -Tipo $f.Tipo -Id $f.Id -Nombre $f.DisplayName -Accion 'Eliminar' -Resultado ERROR -Detalle $_.Exception.Message
        }
    }
}

# ---------------------------------------------------------------- Grupos
if ($ArchivoGrupos) {
    foreach ($f in Import-Aprobados -Archivo $ArchivoGrupos) {
        try {
            if (-not (Test-ListoParaF4 -Fila $f -Tipo 'Grupo')) { continue }
            $g = Get-MgGroup -GroupId $f.Id -Property Id,DisplayName,GroupTypes,MailEnabled,SecurityEnabled,Mail,Description,AssignedLicenses,ProxyAddresses
            $tipo = Get-TipoGrupo $g
            if (@($g.AssignedLicenses).Count -gt 0) {
                Write-Bitacora -Fase F4 -Tipo Grupo -Id $f.Id -Nombre $f.DisplayName -Accion 'Eliminar' -Resultado OMITIDO -Detalle 'El grupo asigna licencias'
                continue
            }
            $respaldo.Grupos += [pscustomobject]@{
                Id = $g.Id; DisplayName = $g.DisplayName; Tipo = $tipo; Mail = $g.Mail; Descripcion = $g.Description
                ProxyAddresses = @($g.ProxyAddresses)
                Miembros = @(Get-MgGroupMember -GroupId $f.Id -All | ForEach-Object { $_.Id })
                Propietarios = @(Get-MgGroupOwner -GroupId $f.Id -All | ForEach-Object { $_.Id })
            }
            $nota = if ($tipo -eq 'M365') { 'Papelera 30 dias' } else { 'PERMANENTE (sin papelera)' }
            if ($Ejecutar) {
                if ($tipo -in 'Distribucion','SeguridadCorreo') { Remove-DistributionGroup -Identity $f.Id -Confirm:$false -BypassSecurityGroupManagerCheck }
                else { Remove-MgGroup -GroupId $f.Id }
            }
            Write-Bitacora -Fase F4 -Tipo Grupo -Id $f.Id -Nombre $f.DisplayName -Accion "Eliminar grupo $tipo" -Resultado $res -Detalle $nota
        } catch {
            Write-Bitacora -Fase F4 -Tipo Grupo -Id $f.Id -Nombre $f.DisplayName -Accion 'Eliminar' -Resultado ERROR -Detalle $_.Exception.Message
        }
    }
}

# ---------------------------------------------------------------- Dispositivos
if ($ArchivoDispositivos) {
    foreach ($f in Import-Aprobados -Archivo $ArchivoDispositivos) {
        try {
            if ($f.Motivos -match 'D03') {
                Write-Bitacora -Fase F4 -Tipo Dispositivo -Id $f.Id -Nombre $f.DisplayName -Accion 'Eliminar' -Resultado OMITIDO -Detalle 'Registrado en Autopilot'
                continue
            }
            if (-not (Test-ListoParaF4 -Fila $f -Tipo 'Dispositivo')) { continue }
            $d = Get-MgDevice -DeviceId $f.Id -Property Id,DeviceId,DisplayName,OperatingSystem,TrustType
            $respaldo.Dispositivos += [pscustomobject]@{ Id = $d.Id; DeviceId = $d.DeviceId; DisplayName = $d.DisplayName; SO = $d.OperatingSystem; TipoUnion = $d.TrustType }
            if ($Ejecutar) {
                if ($IncluirIntune) {
                    foreach ($md in @(Get-MgDeviceManagementManagedDevice -Filter "azureADDeviceId eq '$($d.DeviceId)'" -All)) {
                        Remove-MgDeviceManagementManagedDevice -ManagedDeviceId $md.Id
                    }
                }
                Remove-MgDevice -DeviceId $f.Id
            }
            Write-Bitacora -Fase F4 -Tipo Dispositivo -Id $f.Id -Nombre $f.DisplayName -Accion 'Eliminar dispositivo' -Resultado $res -Detalle $(if ($IncluirIntune) { 'Entra + Intune' } else { 'Solo Entra' })
        } catch {
            Write-Bitacora -Fase F4 -Tipo Dispositivo -Id $f.Id -Nombre $f.DisplayName -Accion 'Eliminar' -Resultado ERROR -Detalle $_.Exception.Message
        }
    }
}

$archR = Join-Path $Script:RutaRespaldo "Respaldo_F4_$($Script:Marca).json"
$respaldo | ConvertTo-Json -Depth 6 | Set-Content -Path $archR -Encoding utf8
Write-Host "`nRespaldo final: $archR" -ForegroundColor Cyan
if (-not $Ejecutar) { Write-Host 'MODO SIMULACION: no se cambio nada. Agrega -Ejecutar para aplicar.' -ForegroundColor Yellow }
