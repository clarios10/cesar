<#
.SYNOPSIS
  Reversion de la Fase 3 (y opcionalmente de la Fase 2). Usa el respaldo JSON que genero 03-Deshabilitar.ps1.

.DESCRIPTION
  Revierte solo los Id indicados (parametro -Ids o archivo CSV con columna Id), o todos con -Todos.
    Usuarios    : habilita el inicio de sesion y restaura la visibilidad del buzon.
    Grupos      : vuelve a mostrarlos, quita la restriccion de envio y restaura miembros si se vaciaron.
    Dispositivos: vuelve a habilitarlos.
  La etiqueta regresa a F2 (o se borra con -QuitarEtiqueta, que tambien restaura la descripcion original de grupos
  si se indica -RespaldoF2).
  Por defecto SIMULA. Agrega -Ejecutar para aplicar.

.EXAMPLE
  .\03b-Revertir.ps1 -RespaldoF3 .\respaldo\Respaldo_F3_20261101_101500.json -Ids 3f668e7c-a7b5-4d1f-935d-966449595b1c -Ejecutar
  .\03b-Revertir.ps1 -RespaldoF3 ... -ArchivoIds .\revertir.csv -QuitarEtiqueta -RespaldoF2 .\respaldo\Respaldo_F2_....csv -Ejecutar
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$RespaldoF3,
    [string[]]$Ids,
    [string]$ArchivoIds,
    [switch]$Todos,
    [switch]$QuitarEtiqueta,
    [string]$RespaldoF2,
    [switch]$Ejecutar
)

. "$PSScriptRoot\Comun.ps1"
Start-Bitacora -Nombre 'F3_Revertir'
Connect-Servicios -Escritura

$res = if ($Ejecutar) { 'OK' } else { 'SIMULADO' }
$r = Get-Content $RespaldoF3 -Raw | ConvertFrom-Json
$objetivo = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
if ($Ids) { $Ids | ForEach-Object { [void]$objetivo.Add($_) } }
if ($ArchivoIds) { Import-Csv $ArchivoIds | ForEach-Object { [void]$objetivo.Add($_.Id) } }
if (-not $Todos -and $objetivo.Count -eq 0) { throw 'Indica -Ids, -ArchivoIds o -Todos.' }

$descOriginal = @{}
if ($RespaldoF2) { Import-Csv $RespaldoF2 | ForEach-Object { $descOriginal[$_.Id] = $_.DescripcionOriginal } }

function Test-Objetivo { param([string]$Id) return ($Todos -or $objetivo.Contains($Id)) }

function Restore-Etiqueta {
    param([string]$Tipo, [string]$Id)
    if ($QuitarEtiqueta) {
        if ($Tipo -eq 'Grupo' -and $descOriginal.ContainsKey($Id)) {
            Update-MgGroup -GroupId $Id -BodyParameter @{ description = $(if ($descOriginal[$Id]) { $descOriginal[$Id] } else { $null }) }
        } else {
            Set-Etiqueta -Tipo $Tipo -Id $Id -Valor $null
        }
    } else {
        $et = Get-Etiqueta -Tipo $Tipo -Id $Id
        $motivos = if ($et) { ($et.Split('|') | Select-Object -Skip 3) -join '|' } else { '' }
        Set-Etiqueta -Tipo $Tipo -Id $Id -Valor (New-ValorEtiqueta -Fase 'F2' -Motivos $motivos)
    }
}

foreach ($u in @($r.Usuarios)) {
    if (-not (Test-Objetivo $u.Id)) { continue }
    try {
        if ($Ejecutar) {
            if ($u.Habilitado) { Update-MgUser -UserId $u.Id -AccountEnabled:$true }
            if ($u.TieneBuzon -and $u.OcultoEnLibreta -eq $false) { Set-Mailbox -Identity $u.Id -HiddenFromAddressListsEnabled $false }
            $tipo = (Get-MgUser -UserId $u.Id -Property UserType).UserType
            Restore-Etiqueta -Tipo $(if ($tipo -eq 'Guest') { 'Invitado' } else { 'Usuario' }) -Id $u.Id
        }
        Write-Bitacora -Fase F3R -Tipo Usuario -Id $u.Id -Nombre $u.UPN -Accion 'Rehabilitar' -Resultado $res
    } catch { Write-Bitacora -Fase F3R -Tipo Usuario -Id $u.Id -Nombre $u.UPN -Accion 'Rehabilitar' -Resultado ERROR -Detalle $_.Exception.Message }
}

foreach ($g in @($r.Grupos)) {
    if (-not (Test-Objetivo $g.Id)) { continue }
    try {
        if ($Ejecutar) {
            switch ($g.Tipo) {
                'M365' { Set-UnifiedGroup -Identity $g.Id -HiddenFromAddressListsEnabled $false -HiddenFromExchangeClientsEnabled:$false }
                { $_ -in 'Distribucion','SeguridadCorreo' } {
                    Set-DistributionGroup -Identity $g.Id -HiddenFromAddressListsEnabled $false -AcceptMessagesOnlyFromSendersOrMembers $null -BypassSecurityGroupManagerCheck
                }
                'Seguridad' {
                    if ($g.Vaciado) {
                        foreach ($m in @($g.Miembros)) {
                            try { New-MgGroupMember -GroupId $g.Id -DirectoryObjectId $m } catch { if ($_.Exception.Message -notmatch 'already exist') { throw } }
                        }
                    }
                }
            }
            Restore-Etiqueta -Tipo Grupo -Id $g.Id
        }
        Write-Bitacora -Fase F3R -Tipo Grupo -Id $g.Id -Nombre $g.DisplayName -Accion 'Restaurar' -Resultado $res -Detalle $g.Tipo
    } catch { Write-Bitacora -Fase F3R -Tipo Grupo -Id $g.Id -Nombre $g.DisplayName -Accion 'Restaurar' -Resultado ERROR -Detalle $_.Exception.Message }
}

foreach ($d in @($r.Dispositivos)) {
    if (-not (Test-Objetivo $d.Id)) { continue }
    try {
        if ($Ejecutar) {
            if ($d.Habilitado) { Update-MgDevice -DeviceId $d.Id -BodyParameter @{ accountEnabled = $true } }
            Restore-Etiqueta -Tipo Dispositivo -Id $d.Id
        }
        Write-Bitacora -Fase F3R -Tipo Dispositivo -Id $d.Id -Nombre $d.DisplayName -Accion 'Rehabilitar' -Resultado $res
    } catch { Write-Bitacora -Fase F3R -Tipo Dispositivo -Id $d.Id -Nombre $d.DisplayName -Accion 'Rehabilitar' -Resultado ERROR -Detalle $_.Exception.Message }
}

if (-not $Ejecutar) { Write-Host 'MODO SIMULACION: no se cambio nada. Agrega -Ejecutar para aplicar.' -ForegroundColor Yellow }
