<#
.SYNOPSIS
  Fase 3 - Deshabilitar. Corta el acceso sin borrar datos. Todo es reversible con 03b-Revertir.ps1.

.DESCRIPTION
  Solo procesa filas Aprobado = SI, AccionPropuesta = Baja y con etiqueta vigente en F2
  (y al menos -DiasAviso dias desde el etiquetado).
    Usuarios / invitados : bloquea el inicio de sesion, revoca sesiones, oculta el buzon de la libreta.
                           NO quita licencias (asi buzon y OneDrive siguen intactos durante la cuarentena).
    Grupos M365          : se ocultan de la libreta y de Outlook.
    Listas de distribucion: se ocultan y solo aceptan correo de la cuenta indicada en -CuentaControl.
    Grupos de seguridad  : se respaldan miembros; con -VaciarGruposSeguridad se quitan los miembros.
    Dispositivos         : se respaldan claves BitLocker y se deshabilita el objeto.
  Respaldo completo en .\respaldo\Respaldo_F3_<marca>.json
  Por defecto SIMULA. Agrega -Ejecutar para aplicar.

.EXAMPLE
  .\03-Deshabilitar.ps1 -ArchivoUsuarios .\salida\Candidatos_Usuarios_2026-10-20.csv -DiasAviso 7
  .\03-Deshabilitar.ps1 -ArchivoGrupos ... -CuentaControl admin.ti@supraterra.com.mx -Ejecutar
#>
[CmdletBinding()]
param(
    [string]$ArchivoUsuarios,
    [string]$ArchivoGrupos,
    [string]$ArchivoDispositivos,
    [int]$DiasAviso = 7,
    [string]$CuentaControl,
    [switch]$VaciarGruposSeguridad,
    [switch]$Ejecutar
)

. "$PSScriptRoot\Comun.ps1"
Start-Bitacora -Nombre 'F3_Deshabilitar'
Connect-Servicios -Escritura
Assert-TenantNube
if (-not $CuentaControl) { $CuentaControl = (Get-MgContext).Account }

$res = if ($Ejecutar) { 'OK' } else { 'SIMULADO' }
$respaldo = [ordered]@{ Fecha = $Script:Hoy; Usuarios = @(); Grupos = @(); Dispositivos = @() }

function Test-ListoParaF3 {
    param($Fila, [string]$Tipo)
    $et = Get-Etiqueta -Tipo $Tipo -Id $Fila.Id
    $chk = Test-EtiquetaFase -Etiqueta $et -FaseEsperada 'F2' -DiasMinimos $DiasAviso
    if (-not $chk.Ok) {
        Write-Bitacora -Fase F3 -Tipo $Tipo -Id $Fila.Id -Nombre $Fila.DisplayName -Accion 'Deshabilitar' -Resultado OMITIDO -Detalle $chk.Motivo
    }
    return $chk.Ok
}

# ---------------------------------------------------------------- Usuarios
if ($ArchivoUsuarios) {
    foreach ($f in Import-Aprobados -Archivo $ArchivoUsuarios) {
        try {
            if (-not (Test-ListoParaF3 -Fila $f -Tipo $f.Tipo)) { continue }
            $u = Get-MgUser -UserId $f.Id -Property Id,UserPrincipalName,AccountEnabled,AssignedLicenses
            $grp = @(Get-MgUserMemberOf -UserId $f.Id -All | Where-Object { $_.AdditionalProperties['@odata.type'] -eq '#microsoft.graph.group' } | ForEach-Object { $_.Id })
            $mbx = Get-EXOMailbox -Identity $f.Id -Properties HiddenFromAddressListsEnabled -ErrorAction SilentlyContinue
            $respaldo.Usuarios += [pscustomobject]@{
                Id = $u.Id; UPN = $u.UserPrincipalName; Habilitado = $u.AccountEnabled
                Licencias = @($u.AssignedLicenses | ForEach-Object { $_.SkuId.ToString() })
                Grupos = $grp; TieneBuzon = [bool]$mbx
                OcultoEnLibreta = $(if ($mbx) { $mbx.HiddenFromAddressListsEnabled } else { $null })
            }
            if ($Ejecutar) {
                if ($u.AccountEnabled) { Update-MgUser -UserId $f.Id -AccountEnabled:$false }
                Revoke-MgUserSignInSession -UserId $f.Id | Out-Null
                if ($mbx) { Set-Mailbox -Identity $f.Id -HiddenFromAddressListsEnabled $true }
                Set-Etiqueta -Tipo $f.Tipo -Id $f.Id -Valor (New-ValorEtiqueta -Fase 'F3' -Motivos $f.Motivos)
            }
            Write-Bitacora -Fase F3 -Tipo $f.Tipo -Id $f.Id -Nombre $f.DisplayName -Accion 'Bloquear inicio, revocar sesiones, ocultar buzon' -Resultado $res
        } catch {
            Write-Bitacora -Fase F3 -Tipo $f.Tipo -Id $f.Id -Nombre $f.DisplayName -Accion 'Deshabilitar' -Resultado ERROR -Detalle $_.Exception.Message
        }
    }
}

# ---------------------------------------------------------------- Grupos
if ($ArchivoGrupos) {
    foreach ($f in Import-Aprobados -Archivo $ArchivoGrupos) {
        try {
            if (-not (Test-ListoParaF3 -Fila $f -Tipo 'Grupo')) { continue }
            $g = Get-MgGroup -GroupId $f.Id -Property Id,DisplayName,GroupTypes,MailEnabled,SecurityEnabled,Mail,Description,AssignedLicenses
            $tipo = Get-TipoGrupo $g
            if (@($g.AssignedLicenses).Count -gt 0) {
                Write-Bitacora -Fase F3 -Tipo Grupo -Id $f.Id -Nombre $f.DisplayName -Accion 'Deshabilitar' -Resultado OMITIDO -Detalle 'El grupo asigna licencias'
                continue
            }
            $miembros = @(Get-MgGroupMember -GroupId $f.Id -All | ForEach-Object { $_.Id })
            $duenos = @(Get-MgGroupOwner -GroupId $f.Id -All | ForEach-Object { $_.Id })
            $respaldo.Grupos += [pscustomobject]@{ Id = $g.Id; DisplayName = $g.DisplayName; Tipo = $tipo; Mail = $g.Mail; Miembros = $miembros; Propietarios = $duenos; Vaciado = $false }

            $accion = ''
            switch ($tipo) {
                'M365' {
                    $accion = 'Ocultar de libreta y de Outlook'
                    if ($Ejecutar) { Set-UnifiedGroup -Identity $f.Id -HiddenFromAddressListsEnabled $true -HiddenFromExchangeClientsEnabled:$true }
                }
                { $_ -in 'Distribucion','SeguridadCorreo' } {
                    $accion = "Ocultar y aceptar correo solo de $CuentaControl"
                    if ($Ejecutar) { Set-DistributionGroup -Identity $f.Id -HiddenFromAddressListsEnabled $true -AcceptMessagesOnlyFromSendersOrMembers $CuentaControl -BypassSecurityGroupManagerCheck }
                }
                'Seguridad' {
                    if ($VaciarGruposSeguridad) {
                        $accion = "Quitar $($miembros.Count) miembros (respaldados)"
                        if ($Ejecutar) {
                            foreach ($m in $miembros) { Remove-MgGroupMemberByRef -GroupId $f.Id -DirectoryObjectId $m }
                            $respaldo.Grupos[-1].Vaciado = $true
                        }
                    } else { $accion = 'Solo respaldo de miembros (sin -VaciarGruposSeguridad)' }
                }
            }
            if ($Ejecutar) { Set-Etiqueta -Tipo Grupo -Id $f.Id -Valor (New-ValorEtiqueta -Fase 'F3' -Motivos $f.Motivos) }
            Write-Bitacora -Fase F3 -Tipo Grupo -Id $f.Id -Nombre $f.DisplayName -Accion $accion -Resultado $res -Detalle $tipo
        } catch {
            Write-Bitacora -Fase F3 -Tipo Grupo -Id $f.Id -Nombre $f.DisplayName -Accion 'Deshabilitar' -Resultado ERROR -Detalle $_.Exception.Message
        }
    }
}

# ---------------------------------------------------------------- Dispositivos
if ($ArchivoDispositivos) {
    $clavesBL = [System.Collections.Generic.List[object]]::new()
    foreach ($f in Import-Aprobados -Archivo $ArchivoDispositivos) {
        try {
            if (-not (Test-ListoParaF3 -Fila $f -Tipo 'Dispositivo')) { continue }
            $d = Get-MgDevice -DeviceId $f.Id -Property Id,DeviceId,DisplayName,AccountEnabled
            foreach ($k in @(Get-MgInformationProtectionBitlockerRecoveryKey -Filter "deviceId eq '$($d.DeviceId)'" -All)) {
                $kk = Get-MgInformationProtectionBitlockerRecoveryKey -BitlockerRecoveryKeyId $k.Id -Property key
                $clavesBL.Add([pscustomobject]@{ Dispositivo = $d.DisplayName; DeviceId = $d.DeviceId; IdClave = $k.Id; Creada = $k.CreatedDateTime; Clave = $kk.Key })
            }
            $respaldo.Dispositivos += [pscustomobject]@{ Id = $d.Id; DeviceId = $d.DeviceId; DisplayName = $d.DisplayName; Habilitado = $d.AccountEnabled }
            if ($Ejecutar) {
                if ($d.AccountEnabled) { Update-MgDevice -DeviceId $f.Id -BodyParameter @{ accountEnabled = $false } }
                Set-Etiqueta -Tipo Dispositivo -Id $f.Id -Valor (New-ValorEtiqueta -Fase 'F3' -Motivos $f.Motivos)
            }
            Write-Bitacora -Fase F3 -Tipo Dispositivo -Id $f.Id -Nombre $f.DisplayName -Accion 'Respaldar BitLocker y deshabilitar' -Resultado $res
        } catch {
            Write-Bitacora -Fase F3 -Tipo Dispositivo -Id $f.Id -Nombre $f.DisplayName -Accion 'Deshabilitar' -Resultado ERROR -Detalle $_.Exception.Message
        }
    }
    if ($clavesBL.Count -gt 0) {
        $archBL = Join-Path $Script:RutaRespaldo "BitLocker_F3_$($Script:Marca).csv"
        $clavesBL | Export-Csv $archBL -NoTypeInformation -Encoding $Script:Codificacion
        Write-Warning "Claves BitLocker respaldadas en $archBL. Es informacion SENSIBLE: muevela a una ubicacion protegida."
    }
}

$archR = Join-Path $Script:RutaRespaldo "Respaldo_F3_$($Script:Marca).json"
$respaldo | ConvertTo-Json -Depth 6 | Set-Content -Path $archR -Encoding utf8
Write-Host "`nRespaldo para reversion: $archR" -ForegroundColor Cyan
if (-not $Ejecutar) { Write-Host 'MODO SIMULACION: no se cambio nada. Agrega -Ejecutar para aplicar.' -ForegroundColor Yellow }
Write-Host 'Cuarentena sugerida antes de la Fase 4: 30 dias.' -ForegroundColor Cyan
