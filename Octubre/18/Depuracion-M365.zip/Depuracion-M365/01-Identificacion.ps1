<#
.SYNOPSIS
  Fase 1 - Identificacion. Solo lectura: no cambia nada en el tenant.

.DESCRIPTION
  Genera tres archivos en .\salida para revision y aprobacion del cliente:
    Candidatos_Usuarios_<fecha>.csv      (miembros e invitados)
    Candidatos_Grupos_<fecha>.csv
    Candidatos_Dispositivos_<fecha>.csv
  Cada fila trae Motivos (codigos), AccionPropuesta y las columnas vacias Aprobado / ConservarBuzon / Comentario.
  Las fases 2 a 4 solo actuan sobre filas con Aprobado = SI y AccionPropuesta = Baja.

  Codigos de motivo
    U01 Deshabilitado              U02 Sin inicio de sesion >= N dias   U03 Sin licencia y sin buzon
    U04 Buzon compartido/sala con inicio habilitado                     U05 Buzon compartido con licencia
    U06 UPN onmicrosoft con correo en dominio propio                    U07 Resto de Entra Connect (Sync_*)
    U08 Reenvio a correo externo (informativo)
    I01 Invitacion pendiente >= N dias                                  I02 Invitado sin inicio >= N dias
    GR01 Sin miembros   GR02 Heredado de AD   GR03 Grupo local de SQL Server   GR04 M365 sin propietario
    GR05 Resto de MigrationWiz   GR06 M365 sin actividad >= 180 dias   GR07 Asigna licencias (no borrar)
    D01 Sin actividad >= N dias  D02 Unido hibrido (ServerAd) sin AD   D03 Registrado en Autopilot (no borrar)
    X00 Excluido (administrador o lista de exclusion)

.EXAMPLE
  .\01-Identificacion.ps1
  .\01-Identificacion.ps1 -DiasInactividad 120 -ArchivoExclusiones .\exclusiones.csv
#>
[CmdletBinding()]
param(
    [int]$DiasInactividad = 90,
    [int]$DiasInactividadDispositivo = 90,
    [int]$DiasInvitacionPendiente = 30,
    [string]$ArchivoExclusiones,          # CSV con columna Id o UserPrincipalName
    [switch]$SinTamanoBuzon,              # omite Get-EXOMailboxStatistics (mas rapido)
    [switch]$SinActividadGruposM365       # omite el reporte de actividad de grupos
)

. "$PSScriptRoot\Comun.ps1"
Start-Bitacora -Nombre 'F1_Identificacion'
Connect-Servicios
Assert-TenantNube

$ahora = Get-Date
$limite = $ahora.AddDays(-$DiasInactividad)

# ---------------------------------------------------------------- Catalogos
Write-Host "Leyendo licencias, roles y exclusiones..." -ForegroundColor Cyan
$skus = @{}
Get-MgSubscribedSku -All | ForEach-Object { $skus[$_.SkuId.ToString()] = $_.SkuPartNumber }

$admins = [System.Collections.Generic.HashSet[string]]::new()
foreach ($rol in Get-MgDirectoryRole -All) {
    foreach ($m in Get-MgDirectoryRoleMember -DirectoryRoleId $rol.Id -All) { [void]$admins.Add($m.Id) }
}

$excluidos = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
if ($ArchivoExclusiones) {
    foreach ($e in Import-Csv $ArchivoExclusiones) {
        if ($e.PSObject.Properties['Id'] -and $e.Id) { [void]$excluidos.Add($e.Id) }
        if ($e.PSObject.Properties['UserPrincipalName'] -and $e.UserPrincipalName) { [void]$excluidos.Add($e.UserPrincipalName) }
    }
}

# ---------------------------------------------------------------- Buzones
Write-Host "Leyendo buzones de Exchange Online..." -ForegroundColor Cyan
$buzones = @{}
Get-EXOMailbox -ResultSize Unlimited -Properties ExternalDirectoryObjectId,RecipientTypeDetails,ForwardingSmtpAddress,ForwardingAddress,ArchiveStatus,LitigationHoldEnabled,HiddenFromAddressListsEnabled |
    ForEach-Object { if ($_.ExternalDirectoryObjectId) { $buzones[$_.ExternalDirectoryObjectId] = $_ } }

$tamanos = @{}
if (-not $SinTamanoBuzon) {
    $i = 0
    foreach ($b in $buzones.Values) {
        $i++; Write-Progress -Activity 'Tamano de buzones' -Status $b.PrimarySmtpAddress -PercentComplete ($i * 100 / $buzones.Count)
        try {
            $s = Get-EXOMailboxStatistics -Identity $b.ExternalDirectoryObjectId -Properties LastLogonTime
            $bytes = 0
            if ($s.TotalItemSize -and ($s.TotalItemSize.ToString() -match '\(([\d,\.]+) bytes\)')) { $bytes = [double]($Matches[1] -replace '[,\.]','') }
            $tamanos[$b.ExternalDirectoryObjectId] = [pscustomobject]@{ GB = [math]::Round($bytes / 1GB, 2); UltimoAccesoBuzon = $s.LastLogonTime }
        } catch { }
    }
    Write-Progress -Activity 'Tamano de buzones' -Completed
}

# ---------------------------------------------------------------- Usuarios
Write-Host "Leyendo usuarios (con ultimo inicio de sesion)..." -ForegroundColor Cyan
$propsU = 'Id','DisplayName','UserPrincipalName','Mail','AccountEnabled','UserType','CreatedDateTime','AssignedLicenses',
          'LicenseAssignmentStates','SignInActivity','OnPremisesImmutableId','OnPremisesLastSyncDateTime',
          'ExternalUserState','ExternalUserStateChangeDateTime','OnPremisesExtensionAttributes','Department','JobTitle'
$usuarios = Get-MgUser -All -Property $propsU -PageSize 500

$dominiosPropios = @(Get-MgDomain -All | Where-Object { $_.IsVerified -and $_.Id -notlike '*.onmicrosoft.com' } | ForEach-Object { $_.Id.ToLower() })

$filasU = foreach ($u in $usuarios) {
    $motivos = [System.Collections.Generic.List[string]]::new()
    $accion = 'Conservar'
    $nuevoUpn = ''

    $si = $u.SignInActivity
    $ultimo = $null
    if ($si) { $ultimo = Get-Ultimo @($si.LastSignInDateTime, $si.LastNonInteractiveSignInDateTime, $si.LastSuccessfulSignInDateTime) }
    $dias = if ($ultimo) { [int]($ahora - $ultimo).TotalDays } else { $null }
    $inactivo = ($ultimo -and $ultimo -lt $limite) -or (-not $ultimo -and $u.CreatedDateTime -and [datetime]$u.CreatedDateTime -lt $limite)

    $b = $buzones[$u.Id]
    $tipoBuzon = if ($b) { [string]$b.RecipientTypeDetails } else { 'SinBuzon' }
    $esCompartido = $tipoBuzon -in 'SharedMailbox','RoomMailbox','EquipmentMailbox','SchedulingMailbox'
    $t = $tamanos[$u.Id]

    $lic = @($u.AssignedLicenses | ForEach-Object { $n = $skus[$_.SkuId.ToString()]; if ($n) { $n } else { $_.SkuId } })
    $licGrupo = @($u.LicenseAssignmentStates | Where-Object { $_.AssignedByGroup }).Count -gt 0

    $reenvio = ''
    if ($b -and $b.ForwardingSmtpAddress) {
        $reenvio = ($b.ForwardingSmtpAddress -replace '^smtp:','')
        $domR = ($reenvio.Split('@')[-1]).ToLower()
        if ($dominiosPropios -notcontains $domR) { $motivos.Add('U08') }
    }

    $esAdmin = $admins.Contains($u.Id)
    $tipo = if ($u.UserType -eq 'Guest') { 'Invitado' } else { 'Usuario' }

    if ($esAdmin -or $excluidos.Contains($u.Id) -or $excluidos.Contains($u.UserPrincipalName)) {
        $motivos.Insert(0, 'X00')
    }
    elseif ($tipo -eq 'Invitado') {
        if ($u.ExternalUserState -eq 'PendingAcceptance' -and $u.ExternalUserStateChangeDateTime -and
            [datetime]$u.ExternalUserStateChangeDateTime -lt $ahora.AddDays(-$DiasInvitacionPendiente)) { $motivos.Add('I01') }
        if ($inactivo) { $motivos.Add('I02') }
        if (-not $u.AccountEnabled) { $motivos.Add('U01') }
        if ($motivos | Where-Object { $_ -in 'I01','I02','U01' }) { $accion = 'Baja' }
    }
    else {
        if ($u.UserPrincipalName -like 'Sync_*') { $motivos.Add('U07'); $accion = 'Baja' }
        if (-not $u.AccountEnabled -and -not $esCompartido) { $motivos.Add('U01'); $accion = 'Baja' }

        if ($esCompartido) {
            if ($u.AccountEnabled) { $motivos.Add('U04'); if ($accion -eq 'Conservar') { $accion = 'BloquearInicio' } }
            if ($lic.Count -gt 0)  { $motivos.Add('U05'); if ($accion -eq 'Conservar') { $accion = 'QuitarLicencia' } }
        }
        else {
            if ($u.AccountEnabled -and $inactivo) { $motivos.Add('U02'); $accion = 'Baja' }
            if ($u.AccountEnabled -and $lic.Count -eq 0 -and -not $b) {
                $motivos.Add('U03')
                if ($accion -eq 'Conservar') { $accion = 'Revisar' }   # sin licencia pero con actividad reciente
            }
        }

        if ($u.UserPrincipalName -like '*.onmicrosoft.com' -and $u.Mail -and $u.Mail -notlike '*.onmicrosoft.com' -and $u.UserPrincipalName -notlike 'Sync_*') {
            $motivos.Add('U06'); $nuevoUpn = $u.Mail
            if ($accion -eq 'Conservar') { $accion = 'CorregirUPN' }
        }
    }

    [pscustomobject]@{
        Tipo = $tipo; Id = $u.Id; DisplayName = $u.DisplayName; UserPrincipalName = $u.UserPrincipalName; Mail = $u.Mail
        Habilitado = $u.AccountEnabled; Creado = $u.CreatedDateTime; UltimoInicio = $ultimo; DiasSinInicio = $dias
        Licencias = ($lic -join ';'); LicenciaPorGrupo = $licGrupo; TipoBuzon = $tipoBuzon
        TamanoBuzonGB = $(if ($t) { $t.GB } else { '' }); ArchivoActivo = $(if ($b) { $b.ArchiveStatus } else { '' })
        RetencionLitigio = $(if ($b) { $b.LitigationHoldEnabled } else { '' }); Reenvio = $reenvio
        AntesSincronizado = [bool]$u.OnPremisesImmutableId; EsAdmin = $esAdmin
        Departamento = $u.Department; Puesto = $u.JobTitle
        EtiquetaActual = $u.OnPremisesExtensionAttributes.ExtensionAttribute15
        Motivos = ($motivos -join ';'); AccionPropuesta = $(if ($motivos -contains 'X00') { 'Conservar' } else { $accion })
        NuevoUPN = $nuevoUpn; Aprobado = ''; ConservarBuzon = ''; Comentario = ''
    }
}
$archU = Join-Path $Script:RutaSalida "Candidatos_Usuarios_$($Script:Hoy).csv"
$filasU | Sort-Object AccionPropuesta, Tipo, DisplayName | Export-Csv $archU -NoTypeInformation -Encoding $Script:Codificacion

# ---------------------------------------------------------------- Grupos
Write-Host "Leyendo grupos..." -ForegroundColor Cyan
$actividad = @{}
if (-not $SinActividadGruposM365) {
    try {
        $tmp = Join-Path $Script:RutaSalida "actividad_grupos_tmp.csv"
        Get-MgReportOffice365GroupActivityDetail -Period 'D180' -OutFile $tmp
        foreach ($r in Import-Csv $tmp) { if ($r.'Group Id') { $actividad[$r.'Group Id'] = $r.'Last Activity Date' } }
        Remove-Item $tmp -ErrorAction SilentlyContinue
        if ($actividad.Count -eq 0) { Write-Warning 'El reporte de actividad no trajo Ids (posible ocultamiento de nombres en reportes). GR06 no se evaluara.' }
    } catch { Write-Warning "No se pudo leer el reporte de actividad de grupos: $($_.Exception.Message)" }
}

$grupos = Get-MgGroup -All -Property Id,DisplayName,Mail,GroupTypes,SecurityEnabled,MailEnabled,CreatedDateTime,OnPremisesLastSyncDateTime,Description,AssignedLicenses
$i = 0
$filasG = foreach ($g in $grupos) {
    $i++; Write-Progress -Activity 'Grupos' -Status $g.DisplayName -PercentComplete ($i * 100 / [math]::Max(1, @($grupos).Count))
    $motivos = [System.Collections.Generic.List[string]]::new()
    $accion = 'Conservar'
    $tipo = Get-TipoGrupo $g
    $miembros = @(Get-MgGroupMember -GroupId $g.Id -All -Property Id).Count
    $propietarios = if ($tipo -eq 'M365') { @(Get-MgGroupOwner -GroupId $g.Id -All -Property Id).Count } else { '' }
    $ultAct = $actividad[$g.Id]

    if (@($g.AssignedLicenses).Count -gt 0) { $motivos.Add('GR07') }
    if ($g.DisplayName -match '^(SQLAccessGroup|ReportingGroup|PrivUserGroup|PrivReportingGroup) \{') { $motivos.Add('GR03'); $accion = 'Baja' }
    if ($g.DisplayName -match 'MigrationWiz') { $motivos.Add('GR05'); $accion = 'Baja' }
    if ($miembros -eq 0) { $motivos.Add('GR01'); $accion = 'Baja' }
    if ($g.OnPremisesLastSyncDateTime) { $motivos.Add('GR02'); if ($accion -eq 'Conservar') { $accion = 'Revisar' } }
    if ($tipo -eq 'M365' -and $propietarios -eq 0) { $motivos.Add('GR04'); if ($accion -eq 'Conservar') { $accion = 'Revisar' } }
    if ($tipo -eq 'M365' -and $actividad.Count -gt 0) {
        if (-not $ultAct -or ([datetime]$ultAct -lt $ahora.AddDays(-180))) { $motivos.Add('GR06'); if ($accion -eq 'Conservar') { $accion = 'Revisar' } }
    }
    if ($motivos -contains 'GR07') { $accion = 'Conservar' }   # nunca borrar un grupo que asigna licencias

    [pscustomobject]@{
        Tipo = 'Grupo'; Id = $g.Id; DisplayName = $g.DisplayName; Mail = $g.Mail; TipoGrupo = $tipo
        Creado = $g.CreatedDateTime; HeredadoAD = [bool]$g.OnPremisesLastSyncDateTime; Miembros = $miembros
        Propietarios = $propietarios; UltimaActividad = $ultAct; AsignaLicencias = (@($g.AssignedLicenses).Count -gt 0)
        Descripcion = $g.Description; Motivos = ($motivos -join ';'); AccionPropuesta = $accion
        Aprobado = ''; Comentario = ''
    }
}
Write-Progress -Activity 'Grupos' -Completed
$archG = Join-Path $Script:RutaSalida "Candidatos_Grupos_$($Script:Hoy).csv"
$filasG | Sort-Object AccionPropuesta, TipoGrupo, DisplayName | Export-Csv $archG -NoTypeInformation -Encoding $Script:Codificacion

# ---------------------------------------------------------------- Dispositivos
Write-Host "Leyendo dispositivos y claves BitLocker..." -ForegroundColor Cyan
$bitlocker = @{}
try {
    Get-MgInformationProtectionBitlockerRecoveryKey -All | ForEach-Object { $bitlocker[$_.DeviceId] = 1 + [int]$bitlocker[$_.DeviceId] }
} catch { Write-Warning "No se pudieron leer las claves BitLocker: $($_.Exception.Message)" }

$limiteD = $ahora.AddDays(-$DiasInactividadDispositivo)
$dispositivos = Get-MgDevice -All -Property Id,DeviceId,DisplayName,OperatingSystem,OperatingSystemVersion,TrustType,AccountEnabled,ApproximateLastSignInDateTime,RegistrationDateTime,IsManaged,IsCompliant,PhysicalIds,ExtensionAttributes
$filasD = foreach ($d in $dispositivos) {
    $motivos = [System.Collections.Generic.List[string]]::new()
    $accion = 'Conservar'
    $autopilot = @($d.PhysicalIds | Where-Object { $_ -like '*[ZTDID]*' }).Count -gt 0
    $ult = $d.ApproximateLastSignInDateTime
    if ((-not $ult) -or ([datetime]$ult -lt $limiteD)) { $motivos.Add('D01'); $accion = 'Baja' }
    if ($d.TrustType -eq 'ServerAd') { $motivos.Add('D02'); if ($accion -eq 'Conservar') { $accion = 'Revisar' } }
    if ($autopilot) { $motivos.Add('D03'); $accion = 'Revisar' }   # borrar el objeto rompe Autopilot

    [pscustomobject]@{
        Tipo = 'Dispositivo'; Id = $d.Id; DeviceId = $d.DeviceId; DisplayName = $d.DisplayName
        SistemaOperativo = ("{0} {1}" -f $d.OperatingSystem, $d.OperatingSystemVersion).Trim(); TipoUnion = $d.TrustType
        Habilitado = $d.AccountEnabled; UltimaActividad = $ult; Registrado = $d.RegistrationDateTime
        Administrado = $d.IsManaged; Cumple = $d.IsCompliant; Autopilot = $autopilot
        ClavesBitLocker = [int]$bitlocker[$d.DeviceId]; EtiquetaActual = $d.ExtensionAttributes.ExtensionAttribute15
        Motivos = ($motivos -join ';'); AccionPropuesta = $accion; Aprobado = ''; Comentario = ''
    }
}
$archD = Join-Path $Script:RutaSalida "Candidatos_Dispositivos_$($Script:Hoy).csv"
$filasD | Sort-Object AccionPropuesta, DisplayName | Export-Csv $archD -NoTypeInformation -Encoding $Script:Codificacion

# ---------------------------------------------------------------- Resumen
Write-Host "`n== Resumen de la identificacion" -ForegroundColor White
foreach ($par in @(@('Usuarios', $filasU), @('Grupos', $filasG), @('Dispositivos', $filasD))) {
    Write-Host $par[0] -ForegroundColor White
    @($par[1]) | Group-Object AccionPropuesta | Sort-Object Name | ForEach-Object { Write-Host ("  {0,-15} {1,5}" -f $_.Name, $_.Count) }
    @($par[1]) | Group-Object AccionPropuesta | ForEach-Object {
        Write-Bitacora -Fase F1 -Tipo $par[0] -Id '' -Nombre $_.Name -Accion 'Conteo' -Resultado INFO -Detalle $_.Count
    }
}
Write-Host "`nArchivos para revision:`n  $archU`n  $archG`n  $archD" -ForegroundColor Cyan
Write-Host "Marca Aprobado = SI en las filas autorizadas (y ConservarBuzon = SI cuando aplique). Despues: 02-Etiquetar.ps1" -ForegroundColor Cyan
