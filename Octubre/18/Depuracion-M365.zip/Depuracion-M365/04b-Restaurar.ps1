<#
.SYNOPSIS
  Restaura usuarios o grupos M365 eliminados en la Fase 4 (solo dentro de los 30 dias de papelera).

.DESCRIPTION
  -Listar        muestra lo que hay en la papelera y lo exporta a .\salida\Papelera_<fecha>.csv
  -Ids / -ArchivoIds  restaura esos objetos. Con -RespaldoF4, reasigna licencias directas y vuelve a
                 agregar al usuario a sus grupos. Los usuarios restaurados quedan DESHABILITADOS
                 (como estaban al borrarse); para habilitarlos usa -Habilitar.
  Grupos de seguridad, listas de distribucion y dispositivos NO se pueden restaurar: se recrean a mano
  con el respaldo JSON de la Fase 4.
  Por defecto SIMULA. Agrega -Ejecutar para aplicar.

.EXAMPLE
  .\04b-Restaurar.ps1 -Listar
  .\04b-Restaurar.ps1 -Ids <id> -RespaldoF4 .\respaldo\Respaldo_F4_20261201_090000.json -Habilitar -Ejecutar
#>
[CmdletBinding()]
param(
    [switch]$Listar,
    [string[]]$Ids,
    [string]$ArchivoIds,
    [string]$RespaldoF4,
    [switch]$Habilitar,
    [switch]$Ejecutar
)

. "$PSScriptRoot\Comun.ps1"
Start-Bitacora -Nombre 'F4_Restaurar'
Connect-Servicios -Escritura -SinExchange

if ($Listar) {
    $u = @(Get-MgDirectoryDeletedItemAsUser -All -Property Id,DisplayName,UserPrincipalName,DeletedDateTime | ForEach-Object {
        [pscustomobject]@{ Tipo = 'Usuario'; Id = $_.Id; Nombre = $_.DisplayName; Cuenta = $_.UserPrincipalName; Eliminado = $_.DeletedDateTime; PurgaAprox = ([datetime]$_.DeletedDateTime).AddDays(30) } })
    $g = @(Get-MgDirectoryDeletedItemAsGroup -All -Property Id,DisplayName,Mail,DeletedDateTime | ForEach-Object {
        [pscustomobject]@{ Tipo = 'Grupo'; Id = $_.Id; Nombre = $_.DisplayName; Cuenta = $_.Mail; Eliminado = $_.DeletedDateTime; PurgaAprox = ([datetime]$_.DeletedDateTime).AddDays(30) } })
    $todo = @($u) + @($g)
    $arch = Join-Path $Script:RutaSalida "Papelera_$($Script:Hoy).csv"
    $todo | Sort-Object Eliminado -Descending | Export-Csv $arch -NoTypeInformation -Encoding $Script:Codificacion
    $todo | Format-Table Tipo, Nombre, Cuenta, Eliminado, PurgaAprox -AutoSize
    Write-Host "Exportado: $arch" -ForegroundColor Cyan
    return
}

$lista = @()
if ($Ids) { $lista += $Ids }
if ($ArchivoIds) { $lista += @(Import-Csv $ArchivoIds | ForEach-Object { $_.Id }) }
if ($lista.Count -eq 0) { throw 'Indica -Listar, -Ids o -ArchivoIds.' }

$resp = @{}
if ($RespaldoF4) {
    $j = Get-Content $RespaldoF4 -Raw | ConvertFrom-Json
    foreach ($x in @($j.Usuarios)) { $resp[$x.Id] = $x }
}
$res = if ($Ejecutar) { 'OK' } else { 'SIMULADO' }

foreach ($id in $lista) {
    try {
        if ($Ejecutar) { Restore-MgDirectoryDeletedItem -DirectoryObjectId $id | Out-Null }
        Write-Bitacora -Fase F4R -Tipo Objeto -Id $id -Nombre $id -Accion 'Restaurar de papelera' -Resultado $res

        $b = $resp[$id]
        if ($b) {
            if ($Ejecutar -and @($b.LicenciasDirectas).Count -gt 0) {
                $add = @($b.LicenciasDirectas | ForEach-Object { @{ SkuId = $_ } })
                Set-MgUserLicense -UserId $id -AddLicenses $add -RemoveLicenses @() | Out-Null
            }
            Write-Bitacora -Fase F4R -Tipo Usuario -Id $id -Nombre $b.UPN -Accion "Reasignar $(@($b.LicenciasDirectas).Count) licencias" -Resultado $res
            foreach ($gid in @($b.Grupos)) {
                try {
                    if ($Ejecutar) { New-MgGroupMember -GroupId $gid -DirectoryObjectId $id }
                    Write-Bitacora -Fase F4R -Tipo Usuario -Id $id -Nombre $b.UPN -Accion "Agregar a grupo $gid" -Resultado $res
                } catch { Write-Bitacora -Fase F4R -Tipo Usuario -Id $id -Nombre $b.UPN -Accion "Agregar a grupo $gid" -Resultado INFO -Detalle $_.Exception.Message }
            }
        }
        if ($Habilitar) {
            if ($Ejecutar) {
                Update-MgUser -UserId $id -AccountEnabled:$true
                Set-Etiqueta -Tipo Usuario -Id $id -Valor $null
            }
            Write-Bitacora -Fase F4R -Tipo Usuario -Id $id -Nombre $id -Accion 'Habilitar y quitar etiqueta' -Resultado $res
        }
    } catch {
        Write-Bitacora -Fase F4R -Tipo Objeto -Id $id -Nombre $id -Accion 'Restaurar' -Resultado ERROR -Detalle $_.Exception.Message
    }
}
if (-not $Ejecutar) { Write-Host 'MODO SIMULACION: no se cambio nada. Agrega -Ejecutar para aplicar.' -ForegroundColor Yellow }
Write-Host 'Nota: el buzon y el OneDrive se recuperan junto con la cuenta si se restaura dentro de los 30 dias.' -ForegroundColor Cyan
