<#
.SYNOPSIS
  Fase 2 - Etiquetar. Marca los objetos aprobados para baja, sin afectar su funcionamiento.

.DESCRIPTION
  Solo procesa filas con Aprobado = SI y AccionPropuesta = Baja.
  Escribe la etiqueta  M365DEP|F2|<fecha>|<motivos>  en:
    Usuarios e invitados -> extensionAttribute15
    Dispositivos         -> extensionAttribute15
    Grupos M365/seguridad -> prefijo en la descripcion  (la descripcion original se respalda)
    Listas de distribucion -> CustomAttribute15 (Exchange)
  Ademas genera Notificacion_F2_<fecha>.csv para avisar a jefes/propietarios antes de deshabilitar.
  Por defecto SIMULA. Agrega -Ejecutar para aplicar.

.EXAMPLE
  .\02-Etiquetar.ps1 -ArchivoUsuarios .\salida\Candidatos_Usuarios_2026-10-20.csv
  .\02-Etiquetar.ps1 -ArchivoUsuarios ... -ArchivoGrupos ... -ArchivoDispositivos ... -Ejecutar
#>
[CmdletBinding()]
param(
    [string]$ArchivoUsuarios,
    [string]$ArchivoGrupos,
    [string]$ArchivoDispositivos,
    [switch]$Ejecutar
)

. "$PSScriptRoot\Comun.ps1"
Start-Bitacora -Nombre 'F2_Etiquetar'
Connect-Servicios -Escritura
Assert-TenantNube

$resultado = if ($Ejecutar) { 'OK' } else { 'SIMULADO' }
$respaldo = [System.Collections.Generic.List[object]]::new()
$aviso = [System.Collections.Generic.List[object]]::new()

function Invoke-Etiquetado {
    param($Fila, [string]$Tipo)
    $valor = New-ValorEtiqueta -Fase 'F2' -Motivos $Fila.Motivos
    try {
        $actual = Get-Etiqueta -Tipo $Tipo -Id $Fila.Id
        if ($actual -and $actual -match '^M365DEP\|F[34]\|') {
            Write-Bitacora -Fase F2 -Tipo $Tipo -Id $Fila.Id -Nombre $Fila.DisplayName -Accion 'Etiquetar' -Resultado OMITIDO -Detalle "Ya esta en fase posterior: $actual"
            return
        }
        if ($Tipo -eq 'Grupo') {
            $g = Get-MgGroup -GroupId $Fila.Id -Property Id,Description
            $respaldo.Add([pscustomobject]@{ Tipo = 'Grupo'; Id = $Fila.Id; DisplayName = $Fila.DisplayName; DescripcionOriginal = $g.Description; EtiquetaAnterior = $actual })
        } else {
            $respaldo.Add([pscustomobject]@{ Tipo = $Tipo; Id = $Fila.Id; DisplayName = $Fila.DisplayName; DescripcionOriginal = ''; EtiquetaAnterior = $actual })
        }
        if ($Ejecutar) { Set-Etiqueta -Tipo $Tipo -Id $Fila.Id -Valor $valor }
        Write-Bitacora -Fase F2 -Tipo $Tipo -Id $Fila.Id -Nombre $Fila.DisplayName -Accion 'Etiquetar' -Resultado $resultado -Detalle $valor
    } catch {
        Write-Bitacora -Fase F2 -Tipo $Tipo -Id $Fila.Id -Nombre $Fila.DisplayName -Accion 'Etiquetar' -Resultado ERROR -Detalle $_.Exception.Message
    }
}

if ($ArchivoUsuarios) {
    foreach ($f in Import-Aprobados -Archivo $ArchivoUsuarios) {
        Invoke-Etiquetado -Fila $f -Tipo $f.Tipo     # 'Usuario' o 'Invitado'
        $jefe = $null
        if ($f.Tipo -eq 'Usuario') {
            try { $m = Get-MgUserManager -UserId $f.Id -ErrorAction Stop; $jefe = $m.AdditionalProperties['userPrincipalName'] } catch { }
        }
        $aviso.Add([pscustomobject]@{ Tipo = $f.Tipo; Nombre = $f.DisplayName; Cuenta = $f.UserPrincipalName; Motivos = $f.Motivos; AvisarA = $jefe; ConservarBuzon = $f.ConservarBuzon })
    }
}

if ($ArchivoGrupos) {
    foreach ($f in Import-Aprobados -Archivo $ArchivoGrupos) {
        Invoke-Etiquetado -Fila $f -Tipo 'Grupo'
        $duenos = ''
        try { $duenos = (@(Get-MgGroupOwner -GroupId $f.Id -All) | ForEach-Object { $_.AdditionalProperties['userPrincipalName'] }) -join ';' } catch { }
        $aviso.Add([pscustomobject]@{ Tipo = 'Grupo'; Nombre = $f.DisplayName; Cuenta = $f.Mail; Motivos = $f.Motivos; AvisarA = $duenos; ConservarBuzon = '' })
    }
}

if ($ArchivoDispositivos) {
    foreach ($f in Import-Aprobados -Archivo $ArchivoDispositivos) {
        Invoke-Etiquetado -Fila $f -Tipo 'Dispositivo'
    }
}

$archR = Join-Path $Script:RutaRespaldo "Respaldo_F2_$($Script:Marca).csv"
$respaldo | Export-Csv $archR -NoTypeInformation -Encoding $Script:Codificacion
$archA = Join-Path $Script:RutaSalida "Notificacion_F2_$($Script:Hoy).csv"
$aviso | Export-Csv $archA -NoTypeInformation -Encoding $Script:Codificacion

Write-Host "`nRespaldo de descripciones/etiquetas: $archR" -ForegroundColor Cyan
Write-Host "Lista para notificar a jefes y propietarios: $archA" -ForegroundColor Cyan
if (-not $Ejecutar) { Write-Host 'MODO SIMULACION: no se cambio nada. Agrega -Ejecutar para aplicar.' -ForegroundColor Yellow }
Write-Host 'Periodo sugerido de aviso antes de la Fase 3: 7 a 14 dias.' -ForegroundColor Cyan
