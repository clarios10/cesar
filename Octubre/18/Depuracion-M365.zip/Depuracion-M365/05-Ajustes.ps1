<#
.SYNOPSIS
  Ajustes que NO son bajas: se aplican a objetos que se conservan. Usa el mismo CSV de usuarios de la Fase 1.

.DESCRIPTION
  Procesa filas Aprobado = SI con AccionPropuesta:
    BloquearInicio : buzones compartidos/salas con la cuenta habilitada (U04) -> se bloquea el inicio de sesion.
    QuitarLicencia : buzones compartidos con licencia (U05) -> se quitan licencias directas si el buzon
                     pesa menos de 49 GB y no tiene archivo en linea activo.
    CorregirUPN    : UPN @onmicrosoft.com con correo en dominio propio (U06) -> UPN = columna NuevoUPN.
                     El usuario debe iniciar sesion de nuevo con el UPN nuevo (Outlook, Teams, OneDrive, MFA).
  Por defecto SIMULA. Agrega -Ejecutar para aplicar.

.EXAMPLE
  .\05-Ajustes.ps1 -ArchivoUsuarios .\salida\Candidatos_Usuarios_2026-10-20.csv
  .\05-Ajustes.ps1 -ArchivoUsuarios ... -Solo CorregirUPN -Ejecutar
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$ArchivoUsuarios,
    [ValidateSet('BloquearInicio','QuitarLicencia','CorregirUPN')][string[]]$Solo = @('BloquearInicio','QuitarLicencia','CorregirUPN'),
    [switch]$Ejecutar
)

. "$PSScriptRoot\Comun.ps1"
Start-Bitacora -Nombre 'F5_Ajustes'
Connect-Servicios -Escritura
Assert-TenantNube

$res = if ($Ejecutar) { 'OK' } else { 'SIMULADO' }
$dominios = @(Get-MgDomain -All | Where-Object IsVerified | ForEach-Object { $_.Id.ToLower() })
$respaldo = [System.Collections.Generic.List[object]]::new()

foreach ($f in Import-Aprobados -Archivo $ArchivoUsuarios -Accion $Solo) {
    try {
        $u = Get-MgUser -UserId $f.Id -Property Id,UserPrincipalName,AccountEnabled,LicenseAssignmentStates
        $respaldo.Add([pscustomobject]@{ Id = $u.Id; UPNAnterior = $u.UserPrincipalName; Habilitado = $u.AccountEnabled; Accion = $f.AccionPropuesta })
        switch ($f.AccionPropuesta) {
            'BloquearInicio' {
                if ($Ejecutar -and $u.AccountEnabled) {
                    Update-MgUser -UserId $f.Id -AccountEnabled:$false
                    Revoke-MgUserSignInSession -UserId $f.Id | Out-Null
                }
                Write-Bitacora -Fase F5 -Tipo Usuario -Id $f.Id -Nombre $f.DisplayName -Accion 'Bloquear inicio de sesion (buzon compartido)' -Resultado $res
            }
            'QuitarLicencia' {
                $mbx = Get-EXOMailbox -Identity $f.Id -Properties ArchiveStatus,RecipientTypeDetails
                $st = Get-EXOMailboxStatistics -Identity $f.Id
                $gb = 0
                if ($st.TotalItemSize -and ($st.TotalItemSize.ToString() -match '\(([\d,\.]+) bytes\)')) { $gb = [double]($Matches[1] -replace '[,\.]','') / 1GB }
                if ($mbx.RecipientTypeDetails -ne 'SharedMailbox' -or $gb -ge 49 -or $mbx.ArchiveStatus -eq 'Active') {
                    Write-Bitacora -Fase F5 -Tipo Usuario -Id $f.Id -Nombre $f.DisplayName -Accion 'Quitar licencia' -Resultado OMITIDO -Detalle ("Tipo={0} Tamano={1:N1}GB Archivo={2}" -f $mbx.RecipientTypeDetails, $gb, $mbx.ArchiveStatus)
                    continue
                }
                $lic = @($u.LicenseAssignmentStates | Where-Object { -not $_.AssignedByGroup } | ForEach-Object { $_.SkuId.ToString() } | Select-Object -Unique)
                if ($Ejecutar -and $lic.Count -gt 0) { Set-MgUserLicense -UserId $f.Id -AddLicenses @() -RemoveLicenses $lic | Out-Null }
                Write-Bitacora -Fase F5 -Tipo Usuario -Id $f.Id -Nombre $f.DisplayName -Accion "Quitar $($lic.Count) licencias directas" -Resultado $res -Detalle ("{0:N1} GB" -f $gb)
            }
            'CorregirUPN' {
                $nuevo = ($f.NuevoUPN -as [string]).Trim()
                $dom = if ($nuevo -match '@') { $nuevo.Split('@')[-1].ToLower() } else { '' }
                if (-not $nuevo -or $dominios -notcontains $dom) {
                    Write-Bitacora -Fase F5 -Tipo Usuario -Id $f.Id -Nombre $f.DisplayName -Accion 'Corregir UPN' -Resultado OMITIDO -Detalle "NuevoUPN vacio o dominio no verificado: '$nuevo'"
                    continue
                }
                $choque = Get-MgUser -Filter "userPrincipalName eq '$nuevo'" -ErrorAction SilentlyContinue
                if ($choque -and $choque.Id -ne $f.Id) {
                    Write-Bitacora -Fase F5 -Tipo Usuario -Id $f.Id -Nombre $f.DisplayName -Accion 'Corregir UPN' -Resultado OMITIDO -Detalle "El UPN $nuevo ya lo usa otro objeto"
                    continue
                }
                if ($Ejecutar) { Update-MgUser -UserId $f.Id -UserPrincipalName $nuevo }
                Write-Bitacora -Fase F5 -Tipo Usuario -Id $f.Id -Nombre $f.DisplayName -Accion 'Corregir UPN' -Resultado $res -Detalle "$($u.UserPrincipalName) -> $nuevo"
            }
        }
    } catch {
        Write-Bitacora -Fase F5 -Tipo Usuario -Id $f.Id -Nombre $f.DisplayName -Accion $f.AccionPropuesta -Resultado ERROR -Detalle $_.Exception.Message
    }
}

$archR = Join-Path $Script:RutaRespaldo "Respaldo_F5_$($Script:Marca).csv"
$respaldo | Export-Csv $archR -NoTypeInformation -Encoding $Script:Codificacion
Write-Host "Respaldo (UPN anterior y estado): $archR" -ForegroundColor Cyan
if (-not $Ejecutar) { Write-Host 'MODO SIMULACION: no se cambio nada. Agrega -Ejecutar para aplicar.' -ForegroundColor Yellow }
