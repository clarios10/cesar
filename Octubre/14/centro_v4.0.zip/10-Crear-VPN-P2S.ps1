<#
.SYNOPSIS
    Crea la VPN Punto a Sitio (P2S) con autenticacion Microsoft Entra ID (MFA por Acceso Condicional) para que los usuarios
    entren a la VNet y lleguen a TSplus (Web 443/80 y Escritorio 3389) en la VM App.
.DESCRIPTION
    - Gateway VPN RouteBased SKU VpnGw1AZ (zona-redundante, hasta 250 conexiones P2S) en la GatewaySubnet existente.
    - IP publica Standard estatica y zona-redundante.
    - Tunel OpenVPN + autenticacion Microsoft Entra ID (cliente "Azure VPN Client").
    - Rango de clientes $Cfg.Vpn.ClientPool (por defecto 172.16.201.0/24); se verifica que no se traslape con la VNet.
    - Es idempotente: si el gateway existe, solo revisa/actualiza su configuracion P2S.
    - El aprovisionamiento tarda 30-45 minutos (el script muestra avance cada minuto).
    Despues ejecute .\01b-Aplicar-Reglas-NSG.ps1 para abrir en nsg-app SOLO los puertos de TSplus al rango VPN.
.PARAMETER TenantId
    Tenant de Microsoft Entra donde estan los usuarios (por defecto el de la sesion de Azure o $Cfg.Vpn.TenantId).
.PARAMETER Force
    No pide confirmacion.
#>
[CmdletBinding()]
param(
    [string]$TenantId,
    [switch]$Force
)

. "$PSScriptRoot\00-Config.ps1"
Initialize-AzSession -Modules Az.Accounts, Az.Resources, Az.Network

$v   = $Cfg.Vpn
$rg  = $Cfg.ResourceGroup
$loc = $Cfg.Location

function ConvertTo-IpRange {
    param([string]$Cidr)
    $ip, $len = $Cidr -split '/'
    $b = [System.Net.IPAddress]::Parse($ip).GetAddressBytes()
    [array]::Reverse($b)
    $start = [uint64][BitConverter]::ToUInt32($b, 0)
    [pscustomobject]@{ Start = $start; End = $start + [uint64]([math]::Pow(2, 32 - [int]$len)) - 1 }
}

# --- 1. Datos de autenticacion -----------------------------------------------
if (-not $TenantId) { $TenantId = $v.TenantId }
if (-not $TenantId) { $TenantId = (Get-AzContext).Tenant.Id }
if ($TenantId -notmatch '^[0-9a-fA-F-]{36}$') { throw "TenantId invalido: '$TenantId'." }
$audience = if ($v.AudienceMode -eq 'Manual') { '41b23e61-6c1e-4545-b367-cd054e0ed4b4' } else { 'c632b3df-fb67-4d84-bdcf-b95ad541b5c8' }
$aadTenant = "https://login.microsoftonline.com/$TenantId/"
$aadIssuer = "https://sts.windows.net/$TenantId/"        # la barra final es obligatoria

# --- 2. Verificaciones -------------------------------------------------------
$vnet = Get-AzVirtualNetwork -Name $Cfg.VnetName -ResourceGroupName $rg
$gwSubnet = $vnet.Subnets | Where-Object Name -eq 'GatewaySubnet'
if (-not $gwSubnet) { throw 'No existe GatewaySubnet. Ejecute .\01a-Crear-Red-NSG.ps1 (sin -SkipGatewaySubnet).' }
if ($gwSubnet.NetworkSecurityGroup) { throw 'GatewaySubnet tiene un NSG asociado; Microsoft no lo soporta. Desasocielo antes de crear el gateway.' }
if ([int](($gwSubnet.AddressPrefix[0] -split '/')[1]) -gt 27) { throw 'GatewaySubnet debe ser /27 o mayor.' }

$pool = ConvertTo-IpRange $v.ClientPool
foreach ($p in $vnet.AddressSpace.AddressPrefixes) {
    $r = ConvertTo-IpRange $p
    if ($pool.Start -le $r.End -and $r.Start -le $pool.End) { throw "El rango de clientes VPN $($v.ClientPool) se traslapa con la VNet ($p). Cambie `$Cfg.Vpn.ClientPool." }
}
if ($v.Sku -like '*AZ' -and -not @($v.Zones).Count) { throw 'Los SKU AZ requieren IP publica zona-redundante (`$Cfg.Vpn.Zones). Si la region no tiene zonas, elija otra region o SKU.' }

$gw = Get-AzVirtualNetworkGateway -Name $v.GatewayName -ResourceGroupName $rg -ErrorAction SilentlyContinue

$plan = @(
    "Gateway: $($v.GatewayName)  |  SKU: $($v.Sku)  |  RouteBased  |  Region: $loc",
    "IP publica: $($v.PipName) (Standard, estatica, zonas: $(@($v.Zones) -join ','))",
    "Tunel: OpenVPN  |  Rango de clientes: $($v.ClientPool)",
    "Autenticacion: Microsoft Entra ID  |  Tenant: $TenantId  |  Cliente: $(if ($v.AudienceMode -eq 'Manual') { 'registrado manualmente (heredado)' } else { 'registrado por Microsoft (Windows 11 y macOS)' })",
    $(if ($gw) { 'El gateway YA existe: solo se actualizara la configuracion P2S si difiere.' } else { 'Aprovisionamiento: 30-45 minutos. Tiene costo por hora mientras exista.' })
)
Confirm-Plan -Title 'VPN Punto a Sitio' -Lines $plan -Force:$Force

# --- 3. Crear o actualizar ---------------------------------------------------
if (-not $gw) {
    $pip = Get-AzPublicIpAddress -Name $v.PipName -ResourceGroupName $rg -ErrorAction SilentlyContinue
    if (-not $pip) {
        $pipArgs = @{ Name = $v.PipName; ResourceGroupName = $rg; Location = $loc; Sku = 'Standard'; Tier = 'Regional'; AllocationMethod = 'Static'; Tag = $Cfg.Tags }
        if (@($v.Zones).Count) { $pipArgs.Zone = @($v.Zones) }
        $pip = New-AzPublicIpAddress @pipArgs
        Write-Host "IP publica $($v.PipName) creada." -ForegroundColor Green
    }
    $ipc = New-AzVirtualNetworkGatewayIpConfig -Name 'gwipconfig' -SubnetId $gwSubnet.Id -PublicIpAddressId $pip.Id

    Write-Host "Creando el gateway $($v.GatewayName) (30-45 min). No cierre esta ventana..." -ForegroundColor Cyan
    $job = New-AzVirtualNetworkGateway -Name $v.GatewayName -ResourceGroupName $rg -Location $loc -IpConfigurations $ipc `
        -GatewayType Vpn -VpnType RouteBased -GatewaySku $v.Sku -VpnGatewayGeneration Generation1 `
        -VpnClientProtocol OpenVPN -VpnClientAddressPool $v.ClientPool `
        -AadTenantUri $aadTenant -AadAudienceId $audience -AadIssuerUri $aadIssuer -Tag $Cfg.Tags -AsJob
    $t0 = Get-Date
    while ($job.State -in 'Running', 'NotStarted') {
        Start-Sleep -Seconds 60
        Write-Host ("  ... {0:N0} min transcurridos (estado: {1})" -f ((Get-Date) - $t0).TotalMinutes, $job.State) -ForegroundColor Gray
    }
    if ($job.State -ne 'Completed') { $err = $job.ChildJobs[0].JobStateInfo.Reason.Message; throw "Fallo la creacion del gateway: $err" }
    Receive-Job $job | Out-Null
    $gw = Get-AzVirtualNetworkGateway -Name $v.GatewayName -ResourceGroupName $rg
    Write-Host "Gateway creado (estado: $($gw.ProvisioningState))." -ForegroundColor Green
} else {
    $vc = $gw.VpnClientConfiguration
    $same = (@($vc.VpnClientProtocols) -contains 'OpenVPN') -and (@($vc.VpnClientAddressPool.AddressPrefixes) -contains $v.ClientPool) -and
            ($vc.AadAudience -eq $audience) -and ($vc.AadIssuer -eq $aadIssuer)
    if ($same) { Write-Host 'La configuracion P2S del gateway ya coincide. Sin cambios.' -ForegroundColor Yellow }
    else {
        Write-Host 'Actualizando configuracion P2S del gateway (10-20 min)...' -ForegroundColor Cyan
        Set-AzVirtualNetworkGateway -VirtualNetworkGateway $gw -VpnClientProtocol OpenVPN -VpnClientAddressPool $v.ClientPool `
            -AadTenantUri $aadTenant -AadAudienceId $audience -AadIssuerUri $aadIssuer | Out-Null
        Write-Host 'Configuracion P2S actualizada.' -ForegroundColor Green
    }
}

# --- 4. Perfil del cliente (opcional: si falla, se descarga del portal) -------
Write-Section 'Perfil del cliente VPN'
try {
    $prof = New-AzVpnClientConfiguration -ResourceGroupName $rg -Name $v.GatewayName -AuthenticationMethod EapTls
    if ($prof.VpnProfileSASUrl) { Write-Host "Descargue el perfil (valido unos minutos):`n$($prof.VpnProfileSASUrl)" -ForegroundColor Cyan }
} catch { Write-Host "No se pudo generar el perfil por PowerShell ($($_.Exception.Message)). Descarguelo en el portal." -ForegroundColor Yellow }

$pipNow = Get-AzPublicIpAddress -Name $v.PipName -ResourceGroupName $rg -ErrorAction SilentlyContinue
Write-Host @"

Siguientes pasos:
 1) Portal > $($v.GatewayName) > Configuracion de punto a sitio > 'Descargar cliente VPN' (zip). Dentro de la carpeta AzureVPN
    esta 'azurevpnconfig.xml': es el archivo que importan los usuarios en la aplicacion 'Azure VPN Client' (Microsoft Store en Windows / App Store en macOS).
 2) MFA: Microsoft Entra > Proteccion > Acceso condicional > nueva directiva: Usuarios = grupo de usuarios VPN;
    Aplicaciones de destino = 'Azure VPN' (o 'Azure Virtual Network Gateway'); Conceder = 'Requerir autenticacion multifactor'.
 3) Abrir en nsg-app solo los puertos de TSplus para el rango VPN:  .\01b-Aplicar-Reglas-NSG.ps1 -SubnetOnly snet-app
 4) Validar:  .\01-Validar-Red-NSG.ps1
 5) Los usuarios se conectan a la IP privada de la VM App ($($Cfg.VmApp.PrivateIp)): https://$($Cfg.VmApp.PrivateIp) (TSplus Web) o RDP a $($Cfg.VmApp.PrivateIp) (Escritorio).
"@ -ForegroundColor Green
if ($v.AudienceMode -eq 'Manual') {
    Write-Host "AudienceMode = Manual: un administrador global debe otorgar el consentimiento a la app 'Azure VPN' (Portal del gateway > P2S > 'Grant administrator consent')." -ForegroundColor Yellow
}
