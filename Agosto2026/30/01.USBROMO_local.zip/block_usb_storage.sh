#!/bin/zsh
#
# block_usb_storage.sh
# Expulsa automáticamente cualquier volumen montado que provenga de un
# dispositivo de almacenamiento conectado por USB (discos externos, USB drives).
# Compatible con macOS Ventura (13) y Sonoma (14).
#
# Se ejecuta vía LaunchDaemon cada vez que hay un cambio en /Volumes.

LOGFILE="/var/log/usb_block.log"
DATE=$(date "+%Y-%m-%d %H:%M:%S")

# Recorre todos los volúmenes montados actualmente
for VOL in /Volumes/*; do
    # Ignora el volumen del sistema (raíz)
    if [[ "$VOL" == "/Volumes/Macintosh HD" || "$VOL" == "/Volumes/Macintosh HD - Data" ]]; then
        continue
    fi

    # Verifica si el volumen es un dispositivo USB
    PROTOCOL=$(diskutil info "$VOL" 2>/dev/null | grep -i "Protocol" | grep -i "USB")

    if [[ -n "$PROTOCOL" ]]; then
        echo "$DATE - Dispositivo USB detectado y bloqueado: $VOL" >> "$LOGFILE"
        diskutil unmountDisk force "$VOL" >> "$LOGFILE" 2>&1
    fi
done
