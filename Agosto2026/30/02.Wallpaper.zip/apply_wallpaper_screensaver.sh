#!/bin/zsh
#
# apply_wallpaper_screensaver.sh
# Aplica un wallpaper corporativo y configura el protector de pantalla
# para que se active a los 5 minutos de inactividad y solicite
# contraseña de inmediato (bloqueo de pantalla).
#
# Compatible con macOS Ventura (13) y Sonoma (14).
# IMPORTANTE: debe ejecutarse en la sesión GUI del usuario (vía LaunchAgent),
# no como root ni desde una LaunchDaemon, porque modifica preferencias
# del usuario actualmente conectado.

LOGFILE="$HOME/Library/Logs/wallpaper_screensaver.log"
DATE=$(date "+%Y-%m-%d %H:%M:%S")

# --- 1. Ruta del wallpaper corporativo ---
# Debe existir previamente en el equipo (cópialo con MDM, script de
# instalación, o un paso previo de este mismo despliegue).
WALLPAPER_PATH="/Library/Desktop Pictures/wallpaper_corporativo.jpg"

if [[ -f "$WALLPAPER_PATH" ]]; then
    osascript -e "
    tell application \"System Events\"
        tell every desktop
            set picture to \"$WALLPAPER_PATH\"
        end tell
    end tell" >> "$LOGFILE" 2>&1
    echo "$DATE - Wallpaper aplicado: $WALLPAPER_PATH" >> "$LOGFILE"
else
    echo "$DATE - ERROR: no se encontró el wallpaper en $WALLPAPER_PATH" >> "$LOGFILE"
fi

# --- 2. Tiempo de inactividad del protector de pantalla: 5 minutos (300 s) ---
defaults -currentHost write com.apple.screensaver idleTime -int 300

# --- 3. Solicitar contraseña inmediatamente al activarse el protector/reposo ---
defaults write com.apple.screensaver askForPassword -int 1
defaults write com.apple.screensaver askForPasswordDelay -int 0

echo "$DATE - Screensaver configurado: idleTime=300s, askForPassword=1, delay=0" >> "$LOGFILE"

# --- 4. Reiniciar el proceso del protector de pantalla para aplicar cambios ---
killall cfprefsd >/dev/null 2>&1

exit 0
